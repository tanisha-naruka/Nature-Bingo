-- Nature Bingo: run this once in the Supabase SQL editor.

-- 1) One row of app data per user (profile, XP, quests, bingo, journal, etc.)
create table if not exists public.user_state (
  id uuid primary key references auth.users (id) on delete cascade,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.user_state enable row level security;

drop policy if exists "user_state_select_own" on public.user_state;
drop policy if exists "user_state_insert_own" on public.user_state;
drop policy if exists "user_state_update_own" on public.user_state;
drop policy if exists "user_state_delete_own" on public.user_state;
create policy "user_state_select_own" on public.user_state for select using (auth.uid() = id);
create policy "user_state_insert_own" on public.user_state for insert with check (auth.uid() = id);
create policy "user_state_update_own" on public.user_state for update using (auth.uid() = id) with check (auth.uid() = id);
create policy "user_state_delete_own" on public.user_state for delete using (auth.uid() = id);

-- 2) Storage bucket for profile photos and journal photos.
-- Public read (URLs are unguessable); writes are limited to the user's own folder: <user-id>/<file>.
insert into storage.buckets (id, name, public) values ('media', 'media', true) on conflict (id) do nothing;

drop policy if exists "media_read" on storage.objects;
drop policy if exists "media_insert_own" on storage.objects;
drop policy if exists "media_update_own" on storage.objects;
drop policy if exists "media_delete_own" on storage.objects;
create policy "media_read" on storage.objects for select using (bucket_id = 'media');
create policy "media_insert_own" on storage.objects for insert to authenticated
  with check (bucket_id = 'media' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "media_update_own" on storage.objects for update to authenticated
  using (bucket_id = 'media' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "media_delete_own" on storage.objects for delete to authenticated
  using (bucket_id = 'media' and (storage.foldername(name))[1] = auth.uid()::text);
