import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        forest: { 50: "#f2f7f3", 100: "#e0ede4", 200: "#c0dac9", 300: "#93bda3", 400: "#64a07d", 500: "#42845f", 600: "#316a4a", 700: "#27543c", 800: "#1e4130", 900: "#142d21", 950: "#0b1c14" },
        gold: { 300: "#f3d686", 400: "#e8bd52", 500: "#d6a22f", 600: "#b5841c", 700: "#7f5a12" },
        cream: { 50: "#fdfbf5", 100: "#f7f2e2", 200: "#ece3c9" },
      },
      fontFamily: {
        display: ["var(--font-display)", "ui-serif", "Georgia", "serif"],
        sans: ["var(--font-sans)", "ui-sans-serif", "system-ui", "-apple-system", "'Segoe UI'", "Roboto", "sans-serif"],
      },
      boxShadow: {
        paper: "0 1px 0 rgba(255,255,255,.9) inset, 0 1px 2px rgba(20,45,33,.06), 0 12px 32px -14px rgba(20,45,33,.22)",
        lift: "0 1px 0 rgba(255,255,255,.9) inset, 0 2px 4px rgba(20,45,33,.08), 0 22px 44px -16px rgba(20,45,33,.32)",
        glow: "0 0 0 4px rgba(214,162,47,.25)",
      },
      keyframes: {
        "fade-up": { from: { opacity: "0", transform: "translateY(14px)" }, to: { opacity: "1", transform: "none" } },
        "pop": { "0%": { transform: "scale(.9)", opacity: "0" }, "100%": { transform: "scale(1)", opacity: "1" } },
        float: { "0%,100%": { transform: "translateY(0)" }, "50%": { transform: "translateY(-8px)" } },
      },
      animation: { "fade-up": "fade-up .55s cubic-bezier(.2,.7,.2,1) both", pop: "pop .3s cubic-bezier(.2,.7,.2,1) both", float: "float 5s ease-in-out infinite" },
    },
  },
  plugins: [],
};
export default config;
