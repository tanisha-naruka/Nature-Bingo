"use client";
import { notFound } from "next/navigation";
import { Achievements, Bingo, Community, Dashboard, Explore, Journal, Passport, Quests, ScreenTime, Settings } from "@/views";

const VIEWS: Record<string, () => JSX.Element> = {
  dashboard: Dashboard, explore: Explore, quests: Quests, bingo: Bingo, journal: Journal,
  passport: Passport, achievements: Achievements, community: Community, "screen-time": ScreenTime, settings: Settings,
};

export default function Page({ params }: { params: { view: string } }) {
  const View = VIEWS[params.view];
  if (!View) notFound();
  return <View />;
}
