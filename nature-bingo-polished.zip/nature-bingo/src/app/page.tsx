import Link from "next/link";
import { Icon, IconName, Logo, Reveal, Scenic } from "@/components";
import { btnCls } from "@/lib/app";

const FEATURES: { icon: IconName; title: string; text: string }[] = [
  { icon: "map", title: "Explore Nature", text: "Find parks, trails and gardens, and see your own location on a live map." },
  { icon: "compass", title: "AI Nature Quests", text: "Short, safe quests written by Gemma, an open-weight model, in seconds." },
  { icon: "grid", title: "Nature Bingo", text: "Spot birds, leaves and clouds in real life and complete lines for bonus XP." },
  { icon: "book", title: "Photo Journal", text: "Save notes and photos from every outing. Private to your account." },
  { icon: "award", title: "Nature Passport", text: "Collect twelve stamps by completing quests and visiting new places." },
  { icon: "trophy", title: "Achievements", text: "Earn XP, keep your streak alive and unlock badges and milestones." },
  { icon: "users", title: "Community", text: "Join challenges, share moments and climb the leaderboard." },
  { icon: "chart", title: "Screen-Time Insights", text: "Log your screen minutes, set a goal and see how the week is going." },
];

export default function Landing() {
  return (
    <div>
      <header className="absolute inset-x-0 top-0 z-20">
        <div className="mx-auto flex max-w-6xl items-center gap-6 px-5 py-5">
          <Logo light />
          <nav aria-label="Primary" className="ml-6 hidden gap-6 text-sm font-medium text-cream-100/90 md:flex">
            <a href="#features" className="hover:text-gold-300">Features</a><a href="#how" className="hover:text-gold-300">How it works</a><a href="#open" className="hover:text-gold-300">Open AI</a>
          </nav>
          <div className="ml-auto flex items-center gap-2">
            <Link href="/login" className={btnCls("ghost", "sm") + " !border-white/30 !bg-white/10 !text-white hover:!bg-white/20"}>Log in</Link>
            <Link href="/signup" className={btnCls("gold", "sm")}>Sign up</Link>
          </div>
        </div>
      </header>

      <section className="relative isolate overflow-hidden bg-forest-950 pb-44 pt-32 sm:pt-44">
        <Scenic kind="mountain" className="absolute inset-0 -z-10 h-full w-full opacity-90" />
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-forest-950 via-forest-950/80 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 -z-10 h-40 bg-gradient-to-t from-forest-950 to-transparent" />
        <div className="mx-auto max-w-6xl px-5">
          <div className="grid items-center gap-12 lg:grid-cols-[1.15fr_.85fr]">
          <div className="max-w-2xl animate-fade-up">
            <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-gold-400/40 bg-gold-400/10 px-3.5 py-1 text-sm font-medium text-gold-300"><Icon name="sparkles" size={15} />Powered by open-weight Gemma</p>
            <h1 className="font-display text-5xl font-semibold leading-[1.02] tracking-tight text-cream-50 sm:text-7xl">Less Scrolling.<br /><span className="text-gold-300">More Living.</span></h1>
            <p className="mt-6 max-w-xl text-lg text-cream-100/85">Nature Bingo helps you break free from screen time and reconnect with what really matters: nature. Quests, bingo, a photo journal and a passport, all designed to get you outside.</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/signup" className={btnCls("gold") + " !px-7 !py-3 text-lg"}>Get started free</Link>
              <Link href="/login?demo=1" className={btnCls("ghost") + " !px-7 !py-3 text-lg !border-white/30 !bg-white/10 !text-white hover:!bg-white/20"}>Try the demo</Link>
            </div>
          </div>
          <div aria-hidden="true" className="relative hidden animate-float lg:block">
            <div className="absolute -inset-6 rounded-[2rem] bg-gold-400/10 blur-2xl" />
            <div className="relative rotate-2 rounded-3xl border border-white/15 bg-cream-50/95 p-5 shadow-lift">
              <div className="mb-3 flex items-center justify-between"><span className="font-display text-lg font-semibold text-forest-900">Today&apos;s board</span><span className="rounded-full bg-forest-900 px-2.5 py-0.5 text-xs font-semibold text-gold-300">4 / 9</span></div>
              <div className="grid grid-cols-3 gap-2.5">
                {([["bird", "Find a bird", 1], ["leaf", "Touch a tree", 1], ["flower", "Spot a flower", 0], ["cloud", "Watch clouds", 0], ["sun", "Feel the sun", 1], ["camera", "Nature photo", 0], ["drop", "Hear water", 0], ["music", "Listen", 1], ["mountain", "Smooth stone", 0]] as [IconName, string, number][]).map(([i, t, d]) => (
                  <div key={t} className={`flex aspect-square flex-col items-center justify-center gap-1.5 rounded-xl border-2 p-1 text-center text-[11px] font-semibold leading-tight ${d ? "border-gold-400 bg-gradient-to-br from-forest-600 to-forest-800 text-cream-50" : "border-forest-900/10 bg-white text-forest-800"}`}><Icon name={d ? "check" : i} size={20} className={d ? "text-gold-300" : "text-forest-600"} />{t}</div>
                ))}
              </div>
            </div>
          </div>
          </div>
        </div>
      </section>

      <section aria-label="Highlights" className="relative z-10 mx-auto -mt-24 max-w-5xl px-5">
        <Reveal>
          <div className="grid grid-cols-2 gap-4 rounded-3xl border border-forest-900/10 bg-cream-50 p-6 shadow-paper md:grid-cols-4">
            {[["10", "Dedicated pages", "home"], ["12", "Passport stamps", "award"], ["0", "Keys in your browser", "lock"], ["100%", "Works with local AI", "cpu"]].map(([n, l, i]) => (
              <div key={l} className="flex items-center gap-3"><span className="flex h-11 w-11 items-center justify-center rounded-xl bg-forest-100 text-forest-700"><Icon name={i as IconName} /></span><div><div className="font-display text-2xl font-semibold text-forest-900">{n}</div><div className="text-xs text-forest-700/80">{l}</div></div></div>
            ))}
          </div>
        </Reveal>
      </section>

      <section id="features" className="mx-auto max-w-6xl px-5 py-24">
        <Reveal><h2 className="font-display text-4xl font-semibold text-forest-900">Everything you need to get outside</h2><p className="mt-3 max-w-2xl text-forest-700">Eight connected tools, one calm interface. The screen should be the shortest part of the experience.</p></Reveal>
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((f, i) => (
            <Reveal key={f.title} delay={(i % 4) * 80}>
              <div className="group h-full rounded-2xl border border-forest-900/10 bg-cream-50 p-5 shadow-paper transition-all hover:-translate-y-1 hover:border-gold-400/60">
                <span className="mb-4 flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-forest-600 to-forest-800 text-gold-300 transition-transform group-hover:rotate-6"><Icon name={f.icon} /></span>
                <h3 className="font-display text-lg font-semibold text-forest-900">{f.title}</h3><p className="mt-1 text-sm text-forest-700">{f.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section id="how" className="bg-forest-900 py-24 text-cream-100">
        <div className="mx-auto max-w-6xl px-5">
          <Reveal><h2 className="font-display text-4xl font-semibold text-cream-50">Three steps. Mostly outside.</h2></Reveal>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {[["Pick your interests", "Birds, plants, hiking, photography. Tell us what you love and how much time you have."], ["Take a quest outside", "Gemma writes a short, safe quest. Put the phone in your pocket and go."], ["Log it and grow", "Tick bingo squares, add a journal photo, collect stamps and watch your streak grow."]].map(([t, d], i) => (
              <Reveal key={t} delay={i * 100}><div className="h-full rounded-2xl border border-white/10 bg-white/5 p-6"><div className="font-display text-5xl font-semibold text-gold-400">0{i + 1}</div><h3 className="mt-3 font-display text-xl font-semibold text-cream-50">{t}</h3><p className="mt-2 text-forest-100/80">{d}</p></div></Reveal>
            ))}
          </div>
        </div>
      </section>

      <section id="open" className="mx-auto grid max-w-6xl gap-10 px-5 py-24 lg:grid-cols-2 lg:items-center">
        <Reveal>
          <h2 className="font-display text-4xl font-semibold text-forest-900">Open AI, kept on the server</h2>
          <p className="mt-4 text-forest-700">Quests are written by Gemma. Run it fully offline with Ollama, or call it through Google AI Studio. Either way, API keys live only on the server and never reach your browser. If no model is configured, a demo fallback keeps every feature working.</p>
          <ul className="mt-6 space-y-3 text-forest-800">{["Local-first: Gemma via Ollama, no internet needed", "Server-side keys, rate-limited API route", "Honest labels: every quest says whether Gemma or the demo wrote it"].map((t) => <li key={t} className="flex gap-3"><Icon name="check" className="mt-0.5 text-forest-600" />{t}</li>)}</ul>
        </Reveal>
        <Reveal delay={120}>
          <pre className="overflow-x-auto rounded-2xl bg-forest-950 p-6 text-sm leading-7 text-forest-100 shadow-paper"><code>{`# 1. run Gemma locally
ollama pull gemma3:4b

# 2. point the server at it  (.env.local)
GEMMA_PROVIDER=ollama
OLLAMA_URL=http://localhost:11434

# 3. go
npm run dev`}</code></pre>
        </Reveal>
      </section>

      <section className="mx-auto max-w-6xl px-5 pb-24">
        <Reveal>
          <div className="relative isolate overflow-hidden rounded-3xl bg-forest-800 px-8 py-14 text-center">
            <Scenic kind="sunrise" className="absolute inset-0 -z-10 h-full w-full opacity-30" />
            <h2 className="font-display text-4xl font-semibold text-cream-50">Not just a break, but a better you.</h2>
            <p className="mx-auto mt-3 max-w-xl text-forest-100/85">Create a free account or try the demo, no sign-up needed.</p>
            <div className="mt-7 flex flex-wrap justify-center gap-3"><Link href="/signup" className={btnCls("gold")}>Create account</Link><Link href="/login?demo=1" className={btnCls("ghost") + " !border-white/30 !bg-white/10 !text-white"}>Try demo</Link></div>
          </div>
        </Reveal>
      </section>
      <footer className="border-t border-forest-900/10 bg-cream-50/60 py-10 text-center text-sm text-forest-700">Nature Bingo · Built for the Hacktoberfest 2026 “Touch Grass” challenge · Open-weight AI, open web.</footer>
    </div>
  );
}
