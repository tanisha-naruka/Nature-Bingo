import { AuthForm } from "@/components";
export const metadata = { title: "Log in · Nature Bingo" };
export default function Page() { return <AuthForm mode="login" />; }
