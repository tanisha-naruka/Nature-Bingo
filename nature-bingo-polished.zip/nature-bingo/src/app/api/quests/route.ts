import { NextResponse } from "next/server";
import { buildPrompt, callGemma, demoQuest, modelName, parseQuest, provider, QuestInput } from "@/lib/gemma";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const hits = new Map<string, number[]>();
function limited(ip: string): boolean {
  const now = Date.now();
  const list = (hits.get(ip) ?? []).filter((t) => now - t < 60_000);
  list.push(now);
  hits.set(ip, list);
  return list.length > 12;
}

export async function POST(req: Request) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "local";
  if (limited(ip)) return NextResponse.json({ error: "Too many requests. Please wait a minute." }, { status: 429 });

  let b: Partial<QuestInput>;
  try { b = (await req.json()) as Partial<QuestInput>; } catch { return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 }); }
  const ok =
    typeof b.interest === "string" && b.interest.length > 0 && b.interest.length <= 40 &&
    [5, 15, 30, 60].includes(Number(b.minutes)) &&
    ["Easy", "Medium", "Hard"].includes(String(b.difficulty)) && ["Outdoor", "Indoor"].includes(String(b.setting));
  if (!ok) return NextResponse.json({ error: "Invalid quest options" }, { status: 400 });
  const input: QuestInput = { interest: b.interest as string, minutes: Number(b.minutes), difficulty: b.difficulty as QuestInput["difficulty"], setting: b.setting as QuestInput["setting"] };

  const t0 = Date.now();
  if (provider() === "demo") return NextResponse.json({ quest: demoQuest(input), source: "demo", note: "No Gemma provider configured on the server." });
  try {
    const g = await callGemma(buildPrompt(input));
    return NextResponse.json({ quest: parseQuest(g.text, input), source: "gemma", model: g.model || modelName(), ms: Date.now() - t0 });
  } catch (e) {
    console.error("Gemma request failed:", e instanceof Error ? e.message : e);
    return NextResponse.json({ quest: demoQuest(input), source: "demo", note: "Gemma was unreachable, so a demo quest was used." });
  }
}

/** Reports provider status without ever exposing keys or URLs (used by Settings). */
export async function GET() {
  const p = provider();
  let reachable: boolean | null = null;
  if (p === "ollama") {
    try { reachable = (await fetch(`${process.env.OLLAMA_URL}/api/tags`, { signal: AbortSignal.timeout(2500) })).ok; } catch { reachable = false; }
  }
  return NextResponse.json({ provider: p, model: p === "demo" ? null : modelName(), reachable });
}
