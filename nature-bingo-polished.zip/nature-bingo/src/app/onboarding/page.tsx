"use client";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { Btn, Icon, Logo } from "@/components";
import { INTERESTS } from "@/lib/app";
import { useStore } from "@/lib/store";
import type { Difficulty, Setting } from "@/lib/app";

export default function Onboarding() {
  const { ready, session, data, update } = useStore();
  const router = useRouter();
  useEffect(() => { if (ready && !session) router.replace("/login"); }, [ready, session, router]);
  if (!ready || !session) return null;
  const p = data.prefs;
  const set = (patch: Partial<typeof p>) => update((d) => ({ ...d, prefs: { ...d.prefs, ...patch } }));
  const chip = (on: boolean) => `rounded-xl border px-4 py-2 font-semibold transition-all focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-gold-400/50 ${on ? "border-forest-700 bg-forest-700 text-cream-50" : "border-forest-900/15 bg-white text-forest-800 hover:border-forest-500"}`;
  return (
    <div className="mx-auto max-w-3xl px-5 py-10">
      <Logo />
      <h1 className="mt-8 font-display text-4xl font-semibold text-forest-900">Tell us about your interests</h1>
      <p className="mt-2 text-forest-700">Choose what you love so we can create personalized nature quests for you.</p>
      <fieldset className="mt-8"><legend className="mb-3 font-semibold text-forest-800">Interests</legend>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">{INTERESTS.map((i) => { const on = p.interests.includes(i.name); return (
          <button key={i.name} type="button" aria-pressed={on} onClick={() => set({ interests: on ? p.interests.filter((x) => x !== i.name) : [...p.interests, i.name] })} className={`flex flex-col items-center gap-2 rounded-2xl border p-5 transition-all focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-gold-400/50 ${on ? "border-forest-700 bg-forest-700 text-cream-50 shadow-lg" : "border-forest-900/15 bg-cream-50 text-forest-800 hover:-translate-y-0.5 hover:border-forest-500"}`}><Icon name={i.icon} size={28} />{i.name}</button>); })}</div></fieldset>
      <fieldset className="mt-8"><legend className="mb-3 font-semibold text-forest-800">Time you usually have</legend><div className="flex flex-wrap gap-2">{[5, 15, 30, 60].map((m) => <button key={m} type="button" aria-pressed={p.minutes === m} className={chip(p.minutes === m)} onClick={() => set({ minutes: m })}>{m} min</button>)}</div></fieldset>
      <fieldset className="mt-8"><legend className="mb-3 font-semibold text-forest-800">Difficulty</legend><div className="flex flex-wrap gap-2">{(["Easy", "Medium", "Hard"] as Difficulty[]).map((m) => <button key={m} type="button" aria-pressed={p.difficulty === m} className={chip(p.difficulty === m)} onClick={() => set({ difficulty: m })}>{m}</button>)}</div></fieldset>
      <fieldset className="mt-8"><legend className="mb-3 font-semibold text-forest-800">Where</legend><div className="flex flex-wrap gap-2">{(["Outdoor", "Indoor"] as Setting[]).map((m) => <button key={m} type="button" aria-pressed={p.setting === m} className={chip(p.setting === m)} onClick={() => set({ setting: m })}>{m}</button>)}</div></fieldset>
      <div className="mt-10 flex gap-3"><Btn variant="gold" onClick={() => { set({ onboarded: true }); router.push("/dashboard"); }}>Next: go to dashboard</Btn><Btn variant="ghost" onClick={() => router.push("/dashboard")}>Skip</Btn></div>
    </div>
  );
}
