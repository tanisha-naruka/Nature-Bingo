import { AuthForm } from "@/components";
export const metadata = { title: "Sign up · Nature Bingo" };
export default function Page() { return <AuthForm mode="signup" />; }
