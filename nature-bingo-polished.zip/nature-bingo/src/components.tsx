"use client";
import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { ButtonHTMLAttributes, FormEvent, ReactNode, Suspense, useEffect, useId, useRef, useState } from "react";
import { btnCls, field, labelCls, levelName, levelOf, SceneKind, Variant } from "@/lib/app";
import { isConfigured, useStore } from "@/lib/store";

const ICONS = {
  home: '<path d="M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
  compass: '<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>',
  map: '<path d="M9 4L3 6v14l6-2 6 2 6-2V4l-6 2z"/><path d="M9 4v14M15 6v14"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  book: '<path d="M4 4h12a3 3 0 0 1 3 3v13H7a3 3 0 0 1-3-3z"/><path d="M4 17a3 3 0 0 1 3-3h12"/>',
  award: '<circle cx="12" cy="9" r="6"/><path d="M8.5 14L7 22l5-3 5 3-1.5-8"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-8M22 20H2"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/>',
  leaf: '<path d="M5 19c0-9 5-14 15-15 0 10-5 15-14 15"/><path d="M5 19c3-5 6-8 10-10"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  flame: '<path d="M12 3c1 4 5 5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-6 1-9z"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>',
  wifi: '<path d="M2 8.8a15 15 0 0 1 4-2.4M22 8.8a15 15 0 0 0-8-3.7M5 12.5a10 10 0 0 1 3-1.8M19 12.5a10 10 0 0 0-5-2.3M8.5 16a5 5 0 0 1 7 0M12 20h.01M3 3l18 18"/>',
  cpu: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.5 3-6 6.5-6s6.5 2.5 6.5 6M16 4.5a3.5 3.5 0 0 1 0 7M18 14c2.2.6 3.5 2.6 3.5 5"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5"/>',
  cloud: '<path d="M7 18a4.5 4.5 0 1 1 1-8.9A6 6 0 0 1 19.5 11 3.5 3.5 0 0 1 18 18z"/>',
  camera: '<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
  flower: '<circle cx="12" cy="12" r="2.5"/><circle cx="12" cy="6" r="3"/><circle cx="12" cy="18" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="12" r="3"/>',
  bird: '<path d="M3 17c4 0 6-2 8-6 1-2 3-3 5-3l3-2-1 4c0 6-5 10-11 10H3z"/>',
  drop: '<path d="M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z"/>',
  music: '<path d="M9 18V6l10-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="16.5" cy="16" r="2.5"/>',
  mountain: '<path d="M2 20l7-12 4 6 3-4 6 10z"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  upload: '<path d="M12 16V4M7 9l5-5 5 5M4 20h16"/>',
  logout: '<path d="M9 4H5v16h4M16 8l4 4-4 4M20 12H9"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
  pin: '<path d="M12 21s7-6 7-11a7 7 0 0 0-14 0c0 5 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/>',
  sparkles: '<path d="M12 3l2 5 5 2-5 2-2 5-2-5-5-2 5-2zM19 15l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8z"/>',
  trophy: '<path d="M8 4h8v6a4 4 0 0 1-8 0zM8 6H4v1a4 4 0 0 0 4 4M16 6h4v1a4 4 0 0 1-4 4M12 14v4M8 20h8"/>',
  heart: '<path d="M12 20s-8-5-8-11a4.5 4.5 0 0 1 8-2.5A4.5 4.5 0 0 1 20 9c0 6-8 11-8 11z"/>',
  download: '<path d="M12 4v12M7 11l5 5 5-5M4 20h16"/>',
  lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
} as const;
export type IconName = keyof typeof ICONS;

export function Icon({ name, size = 20, className = "" }: { name: IconName; size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" className={`shrink-0 ${className}`}>
      <g dangerouslySetInnerHTML={{ __html: ICONS[name] }} />
    </svg>
  );
}

export function Btn({ variant = "primary", size = "md", className = "", ...p }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; size?: "sm" | "md" }) {
  return <button {...p} className={`${btnCls(variant, size)} ${className}`} />;
}
export function Card({ className = "", children }: { className?: string; children: ReactNode }) {
  return <div className={`rounded-2xl border border-forest-900/10 bg-cream-50 p-5 shadow-paper transition-shadow duration-300 hover:shadow-lift ${className}`}>{children}</div>;
}
export function Bar({ value, label }: { value: number; label?: string }) {
  const v = Math.max(0, Math.min(100, value));
  return (
    <div role="progressbar" aria-valuenow={Math.round(v)} aria-valuemin={0} aria-valuemax={100} aria-label={label} className="h-2.5 overflow-hidden rounded-full bg-forest-900/10">
      <div className="h-full rounded-full bg-gradient-to-r from-forest-500 to-gold-400 transition-all duration-700" style={{ width: `${v}%` }} />
    </div>
  );
}
export function Ring({ value, label, sub, size = 120 }: { value: number; label: string; sub?: string; size?: number }) {
  const v = Math.max(0, Math.min(100, value)), r = 44, c = 2 * Math.PI * r;
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }} role="img" aria-label={`${label}${sub ? ", " + sub : ""}, ${Math.round(v)} percent`}>
      <svg viewBox="0 0 100 100" width={size} height={size} className="-rotate-90">
        <circle cx="50" cy="50" r={r} fill="none" strokeWidth="9" className="stroke-forest-900/10" />
        <circle cx="50" cy="50" r={r} fill="none" strokeWidth="9" strokeLinecap="round" strokeDasharray={`${(v / 100) * c} ${c}`} className="stroke-forest-600 transition-all duration-700" />
      </svg>
      <div className="absolute text-center leading-tight"><div className="font-display text-2xl font-semibold text-forest-900">{label}</div>{sub && <div className="text-xs text-forest-700/70">{sub}</div>}</div>
    </div>
  );
}
export function Tabs<T extends string>({ items, value, onChange }: { items: T[]; value: T; onChange: (v: T) => void }) {
  return (
    <div role="tablist" className="inline-flex flex-wrap gap-1 rounded-xl bg-forest-900/5 p-1">
      {items.map((t) => (
        <button key={t} role="tab" aria-selected={value === t} onClick={() => onChange(t)} className={`rounded-lg px-4 py-1.5 text-sm font-semibold transition-all focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-gold-400/50 ${value === t ? "bg-forest-700 text-cream-50 shadow" : "text-forest-800 hover:bg-forest-900/5"}`}>{t}</button>
      ))}
    </div>
  );
}
export function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-forest-950/60 p-4 backdrop-blur-sm sm:items-center" onClick={onClose}>
      <div role="dialog" aria-modal="true" aria-label={title} onClick={(e) => e.stopPropagation()} className="max-h-[90vh] w-full max-w-lg animate-fade-up overflow-y-auto rounded-2xl bg-cream-50 p-6 shadow-2xl">
        <div className="mb-4 flex items-center justify-between"><h2 className="font-display text-2xl font-semibold text-forest-900">{title}</h2><button aria-label="Close" onClick={onClose} className="rounded-lg p-1.5 hover:bg-forest-900/10 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-gold-400/50"><Icon name="x" /></button></div>
        {children}
      </div>
    </div>
  );
}
export function Avatar({ src, name, size = 40 }: { src?: string; name: string; size?: number }) {
  return src
    ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={src} alt={`${name}'s profile photo`} width={size} height={size} className="rounded-full object-cover ring-2 ring-gold-400/60" style={{ width: size, height: size }} />
    : <span aria-hidden="true" style={{ width: size, height: size }} className="inline-flex items-center justify-center rounded-full bg-forest-600 font-bold text-cream-50 ring-2 ring-gold-400/60">{name.slice(0, 1).toUpperCase()}</span>;
}

const P: Record<SceneKind, { sky: [string, string]; sun: string; far: string; mid: string; near: string; water: boolean; tree: string }> = {
  forest: { sky: ["#f6e3a8", "#a7cfa0"], sun: "#fff3c4", far: "#7fae8b", mid: "#3f7f5b", near: "#1d3f2e", water: false, tree: "#12291f" },
  lake: { sky: ["#f4b97f", "#f7e3c0"], sun: "#ffd98a", far: "#6f9a8f", mid: "#3f7f6b", near: "#1d3f2e", water: true, tree: "#12291f" },
  sunrise: { sky: ["#ec8f5e", "#fbe2a4"], sun: "#fff0b8", far: "#9a7a8c", mid: "#4f7d62", near: "#1d3f2e", water: true, tree: "#0f2419" },
  meadow: { sky: ["#bfe0d0", "#fbf1c9"], sun: "#fff3c4", far: "#9fcaa4", mid: "#5f9b78", near: "#2f6548", water: false, tree: "#26503a" },
  mountain: { sky: ["#a9cde0", "#f6eed2"], sun: "#fff6d6", far: "#8aa7b4", mid: "#4d7d6b", near: "#1d3f2e", water: false, tree: "#12291f" },
};

export function Scenic({ kind = "forest", className = "" }: { kind?: SceneKind; className?: string }) {
  const id = useId().replace(/:/g, "");
  const p = P[kind];
  const tree = (x: number, s: number) => `M${x} ${220 - 60 * s}l${14 * s} ${44 * s}h${-8 * s}l${12 * s} ${34 * s}h${-52 * s}l${12 * s}-${34 * s}h${-8 * s}z`;
  return (
    <svg viewBox="0 0 400 220" preserveAspectRatio="xMidYMid slice" aria-hidden="true" className={className}>
      <defs><linearGradient id={`sk${id}`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={p.sky[0]} /><stop offset="1" stopColor={p.sky[1]} /></linearGradient>
        <radialGradient id={`sn${id}`}><stop offset="0" stopColor={p.sun} /><stop offset="1" stopColor={p.sun} stopOpacity="0" /></radialGradient></defs>
      <rect width="400" height="220" fill={`url(#sk${id})`} />
      <circle cx="290" cy="80" r="70" fill={`url(#sn${id})`} opacity=".8" /><circle cx="290" cy="80" r="20" fill={p.sun} />
      <g fill="#fff" opacity=".55"><ellipse cx="90" cy="48" rx="26" ry="6" /><ellipse cx="110" cy="42" rx="18" ry="6" /><ellipse cx="200" cy="30" rx="22" ry="5" /></g>
      <path d="M150 62q4-5 8 0M162 54q3-4 6 0" stroke={p.near} strokeWidth="1.4" fill="none" strokeLinecap="round" opacity=".6" />
      <path d="M0 150L60 90l45 50 55-70 70 80 60-55 60 70 50-45v70H0z" fill={p.far} opacity=".75" />
      <path d="M0 170Q90 120 190 160T400 140V220H0z" fill={p.mid} />
      {p.water && <g><rect y="165" width="400" height="55" fill={p.sky[0]} opacity=".35" /><path d="M20 180h80M150 192h120M280 178h90M60 205h100M220 210h130" stroke="#fff" strokeWidth="2" opacity=".5" strokeLinecap="round" /></g>}
      <path d="M0 200Q120 170 230 195T400 185V220H0z" fill={p.near} />
      <g fill={p.tree}><path d={tree(40, 1)} /><path d={tree(78, .7)} /><path d={tree(335, 1.1)} /><path d={tree(372, .75)} /><path d={tree(300, .6)} /></g>
    </svg>
  );
}

export function Reveal({ children, className = "", delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const [on, setOn] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el || typeof IntersectionObserver === "undefined") { setOn(true); return; }
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setOn(true); io.disconnect(); } }, { threshold: 0.12 });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return <div ref={ref} style={{ transitionDelay: `${delay}ms` }} className={`transition-all duration-700 ${on ? "translate-y-0 opacity-100" : "translate-y-6 opacity-0"} ${className}`}>{children}</div>;
}

export function Logo({ light = false, href = "/" }: { light?: boolean; href?: string }) {
  return (
    <Link href={href} className="inline-flex items-center gap-2.5 rounded-lg focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-gold-400/50">
      <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-gold-300 to-gold-500 text-forest-950 shadow-[0_1px_0_rgba(255,255,255,.5)_inset,0_6px_14px_-6px_rgba(127,90,18,.7)] transition-transform hover:rotate-6"><Icon name="leaf" size={20} /></span>
      <span className={`font-display text-xl font-semibold tracking-tight ${light ? "text-cream-50" : "text-forest-900"}`}>Nature Bingo</span>
    </Link>
  );
}

const NAV: { href: string; label: string; icon: IconName; sub: string }[] = [
  { href: "/dashboard", label: "Dashboard", icon: "home", sub: "Your day at a glance" },
  { href: "/explore", label: "Explore Nature", icon: "map", sub: "Discover nearby parks, trails and natural spots" },
  { href: "/quests", label: "AI Nature Quests", icon: "compass", sub: "Personalized quests powered by Gemma" },
  { href: "/bingo", label: "Nature Bingo", icon: "grid", sub: "Complete squares, earn rewards, build your streak" },
  { href: "/journal", label: "Nature Journal", icon: "book", sub: "Capture your moments, thoughts and progress" },
  { href: "/passport", label: "Nature Passport", icon: "award", sub: "Collect stamps, complete quests, explore more" },
  { href: "/achievements", label: "Achievements", icon: "trophy", sub: "Earn XP, unlock badges and reach milestones" },
  { href: "/community", label: "Community", icon: "users", sub: "Share, challenge and grow together" },
  { href: "/screen-time", label: "Screen-Time Insights", icon: "chart", sub: "Understand your habits and build better balance" },
  { href: "/settings", label: "Settings", icon: "settings", sub: "Manage your account, preferences and privacy" },
];

export function Shell({ children }: { children: ReactNode }) {
  const { ready, session, data, signOut } = useStore();
  const path = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  useEffect(() => { if (ready && !session) router.replace("/login"); }, [ready, session, router]);
  useEffect(() => setOpen(false), [path]);
  if (!ready || !session) return <div className="flex min-h-screen items-center justify-center bg-forest-950 text-cream-100" role="status"><span className="flex items-center gap-3"><Icon name="leaf" className="animate-float text-gold-300" size={22} />Loading your trail…</span></div>;
  const cur = NAV.find((n) => path.startsWith(n.href)) ?? NAV[0];
  const side = (
    <nav aria-label="Main" className="flex h-full flex-col gap-1 p-4">
      <div className="px-2 pb-5 pt-1"><Logo light href="/dashboard" /></div>
      {NAV.map((n) => {
        const on = path.startsWith(n.href);
        return (
          <Link key={n.href} href={n.href} aria-current={on ? "page" : undefined} className={`flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition-all focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-gold-400/50 ${on ? "bg-gradient-to-r from-forest-500 to-forest-600 text-white shadow-lg ring-1 ring-white/10" : "text-forest-100/75 hover:bg-white/10 hover:text-white"}`}>
            <Icon name={n.icon} size={19} />{n.label}
          </Link>
        );
      })}
      <div className="mt-auto rounded-2xl bg-white/10 p-3.5 text-forest-100">
        <div className="flex items-center gap-3"><Avatar src={data.profile.avatar} name={data.profile.name} size={40} />
          <div className="min-w-0"><div className="truncate text-sm font-semibold text-white">{data.profile.name}</div><div className="text-xs text-gold-300">Level {levelOf(data.xp)} · {levelName(data.xp)}</div></div></div>
        <button onClick={async () => { await signOut(); router.push("/"); }} className="mt-3 flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-xs hover:bg-white/10 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-gold-400/50"><Icon name="logout" size={15} />Sign out</button>
      </div>
    </nav>
  );
  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[268px_1fr]">
      <a href="#main" className="sr-only z-[70] rounded bg-gold-400 px-3 py-2 focus:not-sr-only focus:fixed focus:left-3 focus:top-3">Skip to content</a>
      <aside className="sticky top-0 hidden h-screen bg-gradient-to-b from-forest-900 to-forest-950 lg:block">{side}</aside>
      {open && <div className="fixed inset-0 z-40 lg:hidden" onClick={() => setOpen(false)}><div className="absolute inset-0 bg-forest-950/60" /><aside className="relative h-full w-72 animate-fade-up bg-gradient-to-b from-forest-900 to-forest-950" onClick={(e) => e.stopPropagation()}>{side}</aside></div>}
      <div className="min-w-0">
        <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-forest-900/10 bg-cream-100/80 px-4 py-3 backdrop-blur-xl sm:px-8">
          <button aria-label="Open menu" onClick={() => setOpen(true)} className="rounded-lg p-2 hover:bg-forest-900/10 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-gold-400/50 lg:hidden"><Icon name="menu" /></button>
          <div className="min-w-0 flex-1"><h1 className="truncate font-display text-xl font-semibold text-forest-900 sm:text-2xl">{cur.label}</h1><p className="hidden truncate text-sm text-forest-700/80 sm:block">{cur.sub}</p></div>
          <div className="flex items-center gap-1.5 rounded-full bg-forest-900 px-3.5 py-1.5 text-sm font-semibold text-gold-300 shadow-md ring-1 ring-gold-400/30"><Icon name="flame" size={16} />{data.streak}<span className="mx-1 text-forest-100/40">|</span>{data.xp} XP</div>
          {session.demo && <span className="hidden rounded-full bg-gold-400/20 px-3 py-1 text-xs font-semibold text-gold-700 md:inline">Demo mode</span>}
        </header>
        <main id="main" key={path} className="animate-fade-up px-4 py-6 sm:px-8">{children}</main>
      </div>
    </div>
  );
}

function Form({ mode }: { mode: "login" | "signup" }) {
  const { signIn, signUp, startDemo, oauth, session, ready } = useStore();
  const router = useRouter();
  const params = useSearchParams();
  const [name, setName] = useState(""), [email, setEmail] = useState(""), [pw, setPw] = useState("");
  const [file, setFile] = useState<File | null>(null), [preview, setPreview] = useState<string>();
  const [err, setErr] = useState(""), [info, setInfo] = useState(""), [busy, setBusy] = useState(false);
  const signup = mode === "signup";

  useEffect(() => { if (ready && session) router.replace("/dashboard"); }, [ready, session, router]);
  useEffect(() => { if (params.get("demo") === "1" && !isConfigured) void demo(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, []);

  async function demo() { setBusy(true); await startDemo(name.trim(), file); router.push("/dashboard"); }
  function pick(f: File | undefined) {
    if (!f) return;
    if (!f.type.startsWith("image/") || f.size > 8_000_000) { setErr("Please choose an image under 8 MB."); return; }
    setErr(""); setFile(f); setPreview(URL.createObjectURL(f));
  }
  async function submit(e: FormEvent) {
    e.preventDefault(); setErr(""); setInfo("");
    if (signup && !name.trim()) return setErr("Please enter your name.");
    if (!isConfigured) { await startDemo(name.trim() || "Explorer", file); router.push(signup ? "/onboarding" : "/dashboard"); return; }
    if (pw.length < 6) return setErr("Password must be at least 6 characters.");
    setBusy(true);
    const r = signup ? await signUp(email.trim(), pw, name.trim(), file) : await signIn(email.trim(), pw);
    setBusy(false);
    if (r === "CONFIRM") return setInfo("Account created. Check your email to confirm, then log in.");
    if (r) return setErr(r);
    router.push(signup ? "/onboarding" : "/dashboard");
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="relative isolate hidden flex-col justify-between overflow-hidden bg-forest-900 p-10 lg:flex">
        <Scenic kind="forest" className="absolute inset-0 -z-10 h-full w-full opacity-40" />
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-forest-950/80 via-transparent to-forest-950/90" />
        <Logo light />
        <div><p className="font-display text-4xl font-semibold leading-tight text-cream-50">Nature is not a place to visit,<br /><span className="text-gold-300">it is home.</span></p><p className="mt-4 max-w-sm text-forest-100/80">Join a community of nature lovers and start your journey toward a healthier, happier you.</p></div>
        <p className="text-sm text-forest-100/60">Small steps. Big changes.</p>
      </div>
      <div className="flex items-center justify-center p-5 sm:p-10">
        <form onSubmit={submit} className="w-full max-w-md animate-fade-up rounded-3xl border border-forest-900/10 bg-cream-50 p-7 shadow-lift sm:p-9" noValidate>
          <div className="mb-2 lg:hidden"><Logo /></div>
          <h1 className="font-display text-3xl font-semibold text-forest-900">{signup ? "Create your account" : "Welcome back"}</h1>
          <p className="mt-1 text-sm text-forest-700">{signup ? "Join and start your journey." : "Log in to continue your journey."}</p>
          {!isConfigured && <p className="mt-4 rounded-xl bg-gold-400/15 p-3 text-sm text-gold-700" role="note">Supabase is not configured, so this runs in <b>demo mode</b>: your data stays in this browser.</p>}
          {signup && (<>
            <label className={labelCls} htmlFor="name">Full name</label><input id="name" className={field} value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" placeholder="Alex Carter" />
            <span className={labelCls}>Profile photo (optional)</span>
            <div className="flex items-center gap-4"><Avatar src={preview} name={name || "?"} size={56} />
              <label className="cursor-pointer rounded-xl border border-forest-900/20 bg-white px-4 py-2 text-sm font-semibold text-forest-800 focus-within:ring-4 focus-within:ring-gold-400/50 hover:bg-forest-50"><Icon name="upload" size={16} className="mr-2 inline" />Upload photo<input type="file" accept="image/*" className="sr-only" onChange={(e) => pick(e.target.files?.[0])} /></label></div>
          </>)}
          <label className={labelCls} htmlFor="email">Email address</label><input id="email" type="email" className={field} value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" placeholder="you@example.com" required={isConfigured} />
          <label className={labelCls} htmlFor="pw">Password</label><input id="pw" type="password" className={field} value={pw} onChange={(e) => setPw(e.target.value)} autoComplete={signup ? "new-password" : "current-password"} placeholder="At least 6 characters" required={isConfigured} />
          <div aria-live="polite">{err && <p className="mt-3 rounded-lg bg-red-50 p-2.5 text-sm text-red-800">{err}</p>}{info && <p className="mt-3 rounded-lg bg-forest-100 p-2.5 text-sm text-forest-800">{info}</p>}</div>
          <Btn type="submit" disabled={busy} className="mt-5 w-full">{busy ? "Please wait…" : signup ? "Sign up" : "Log in"}</Btn>
          <Btn type="button" variant="gold" disabled={busy} onClick={demo} className="mt-3 w-full">Continue in demo mode</Btn>
          <div className="my-5 flex items-center gap-3 text-xs text-forest-700"><span className="h-px flex-1 bg-forest-900/15" />or continue with<span className="h-px flex-1 bg-forest-900/15" /></div>
          <div className="grid grid-cols-2 gap-3"><Btn type="button" variant="ghost" disabled={!isConfigured} onClick={() => oauth("google")}>Google</Btn><Btn type="button" variant="ghost" disabled={!isConfigured} onClick={() => oauth("github")}>GitHub</Btn></div>
          <p className="mt-5 text-center text-sm text-forest-700">{signup ? <>Already have an account? <Link className="font-semibold underline" href="/login">Log in</Link></> : <>New here? <Link className="font-semibold underline" href="/signup">Sign up</Link></>}</p>
        </form>
      </div>
    </div>
  );
}
export function AuthForm({ mode }: { mode: "login" | "signup" }) {
  return <Suspense fallback={null}><Form mode={mode} /></Suspense>;
}
