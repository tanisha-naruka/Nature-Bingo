"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { FormEvent, useEffect, useState } from "react";
import { Avatar, Bar, Btn, Card, Icon, Modal, Ring, Scenic, Tabs } from "@/components";
import { BADGES, BINGO_POOL, btnCls, CHALLENGES, dayKey, Difficulty, FEED, field, hasLine, INTERESTS, JournalEntry, labelCls, lastDays, LEADERBOARD, levelName, levelOf, newUserData, Quest, SCENE_FOR_STAMP, SceneKind, Setting, shuffledTiles, SPOTS, STAMP_FOR_TYPE, STAMPS, uid, XP_BY_DIFFICULTY } from "@/lib/app";
import { isConfigured, useStore } from "@/lib/store";

export function Dashboard() {
  const { data } = useStore();
  const hr = new Date().getHours();
  const days = lastDays(7);
  const today = data.screen[dayKey()] ?? 0;
  const next = data.quests.find((q) => !q.done);
  const max = Math.max(data.goal, ...days.map((d) => data.screen[d.key] ?? 0), 1);
  const used = Math.min(100, (today / data.goal) * 100);
  const h = Math.floor(today / 60), m = today % 60;
  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div><h2 className="font-display text-3xl font-semibold text-forest-900">Good {hr < 12 ? "morning" : hr < 18 ? "afternoon" : "evening"}, {data.profile.name.split(" ")[0]}</h2><p className="text-forest-700">Take a break, explore nature, and make it a habit.</p></div>
      <div className="grid gap-5 lg:grid-cols-3">
        <Card className="flex flex-col justify-between"><div><h3 className="font-display text-lg font-semibold">Daily goal</h3><p className="text-sm text-forest-700">Screen time today</p></div>
          <div className="mt-3 flex items-center gap-5"><Ring value={used} label={today ? `${h}h ${m}m` : "0m"} sub={`of ${Math.floor(data.goal / 60)}h ${data.goal % 60}m`} />
            <p className="text-sm text-forest-700">{today === 0 ? "Log today's minutes to see your progress." : today <= data.goal ? "You are within your goal. Nice balance." : "Over your goal today. Try a short quest."}</p></div>
          <Link href="/screen-time" className={btnCls("ghost", "sm") + " mt-4 self-start"}>Log screen time</Link></Card>
        <Card className="overflow-hidden !p-0 lg:col-span-2"><div className="grid sm:grid-cols-2"><div className="relative h-44 sm:h-auto"><Scenic kind={next ? SCENE_FOR_STAMP[next.stamp] : "forest"} className="absolute inset-0 h-full w-full" /></div>
          <div className="p-5"><p className="text-xs font-semibold uppercase tracking-wider text-gold-700">Next quest</p>{next ? (<><h3 className="mt-1 font-display text-2xl font-semibold">{next.title}</h3><p className="mt-1 text-sm text-forest-700">{next.description}</p><p className="mt-2 text-xs text-forest-700">{next.minutes} min · {next.difficulty} · {next.setting}</p></>) : (<><h3 className="mt-1 font-display text-2xl font-semibold">No quest yet</h3><p className="mt-1 text-sm text-forest-700">Let Gemma write one that fits your time and interests.</p></>)}
            <Link href="/quests" className={btnCls("primary", "sm") + " mt-4"}>{next ? "View quest" : "Get a quest"}</Link></div></div></Card>
      </div>
      <div className="grid gap-5 lg:grid-cols-3">
        <Card className="lg:col-span-2"><div className="flex items-start justify-between"><h3 className="font-display text-lg font-semibold">Weekly progress</h3><span className="text-xs text-forest-700">Dashed line = goal</span></div>
          <div className="relative mt-4 flex h-40 items-end gap-3" role="img" aria-label="Screen minutes for the last 7 days">
            <div className="absolute inset-x-0 border-t border-dashed border-gold-500" style={{ bottom: `${(data.goal / max) * 100}%` }} />
            {days.map((d) => { const v = data.screen[d.key] ?? 0; return (<div key={d.key} className="flex flex-1 flex-col items-center justify-end gap-1"><div className={`w-full rounded-t-lg transition-all duration-700 ${v > data.goal ? "bg-gold-500" : "bg-forest-500"}`} style={{ height: `${(v / max) * 100}%`, minHeight: v ? 4 : 0 }} /><span className="text-xs text-forest-700">{d.label}</span></div>); })}</div></Card>
        <Card><h3 className="font-display text-lg font-semibold">Level {levelOf(data.xp)} · {levelName(data.xp)}</h3><div className="mt-3"><Bar value={data.xp % 100} label="Progress to next level" /></div><p className="mt-2 text-sm text-forest-700">{100 - (data.xp % 100)} XP to level {levelOf(data.xp) + 1}</p>
          <div className="mt-4 grid grid-cols-3 gap-2 text-center">{[["flame", data.streak, "Streak"], ["award", data.stamps.length, "Stamps"], ["compass", data.quests.filter((q) => q.done).length, "Quests"]].map(([i, n, l]) => <div key={String(l)} className="rounded-xl bg-forest-900/5 p-2"><Icon name={i as "flame"} className="mx-auto text-forest-600" size={18} /><div className="font-display text-xl font-semibold">{n}</div><div className="text-xs text-forest-700">{l}</div></div>)}</div></Card>
      </div>
      <Card><div className="flex items-center justify-between"><h3 className="font-display text-lg font-semibold">Recent activity</h3><Link href="/achievements" className="text-sm font-semibold text-forest-700 underline">View achievements</Link></div>
        {data.activity.length === 0 ? <p className="mt-3 text-sm text-forest-700">Complete a quest, tick a bingo square or add a journal entry and it will show up here.</p> :
          <ul className="mt-3 divide-y divide-forest-900/10">{data.activity.slice(0, 5).map((a) => <li key={a.id} className="flex items-center gap-3 py-2.5"><span className="flex h-9 w-9 items-center justify-center rounded-full bg-forest-100 text-forest-700"><Icon name="check" size={16} /></span><div className="flex-1"><p className="text-sm font-medium">{a.text}</p><p className="text-xs text-forest-700">{new Date(a.date).toLocaleDateString()}</p></div><span className="text-sm font-semibold text-gold-700">+{a.xp} XP</span></li>)}</ul>}</Card>
    </div>
  );
}

const TYPES = ["All", "Parks", "Trails", "Gardens", "Forests"] as const;
type T = (typeof TYPES)[number];

export function Explore() {
  const { data, update, award, toast } = useStore();
  const [type, setType] = useState<T>("All");
  const [q, setQ] = useState("");
  const [sel, setSel] = useState(SPOTS[0].id);
  const [pos, setPos] = useState<{ lat: number; lon: number } | null>(null);
  const list = SPOTS.filter((s) => (type === "All" || s.type === type) && s.name.toLowerCase().includes(q.toLowerCase()));
  const locate = () => {
    if (!navigator.geolocation) return toast("Geolocation is not supported in this browser.");
    navigator.geolocation.getCurrentPosition((p) => setPos({ lat: p.coords.latitude, lon: p.coords.longitude }), () => toast("Location permission was denied. You can still browse the sample spots."), { timeout: 10000 });
  };
  const visit = (id: string) => {
    const s = SPOTS.find((x) => x.id === id);
    if (!s || data.visited.includes(id)) return;
    update((d) => ({ ...d, visited: [...d.visited, id] }));
    award(15, `Visited ${s.name}`, STAMP_FOR_TYPE[s.type]);
  };
  return (
    <div className="mx-auto grid max-w-6xl gap-6 lg:grid-cols-[1.2fr_1fr]">
      <div className="space-y-4">
        <div className="relative"><Icon name="search" className="pointer-events-none absolute left-3.5 top-3 text-forest-700" /><input aria-label="Search spots" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search parks, trails or gardens" className="w-full rounded-xl border border-forest-900/15 bg-white py-2.5 pl-11 pr-3 focus:outline-none focus:ring-4 focus:ring-forest-500/20" /></div>
        <Tabs items={[...TYPES]} value={type} onChange={setType} />
        <Card className="!p-0 overflow-hidden">
          {pos ? (<iframe title="Map showing your location" className="h-80 w-full border-0" loading="lazy" src={`https://www.openstreetmap.org/export/embed.html?bbox=${pos.lon - 0.02}%2C${pos.lat - 0.012}%2C${pos.lon + 0.02}%2C${pos.lat + 0.012}&layer=mapnik&marker=${pos.lat}%2C${pos.lon}`} />) : (
            <div className="relative h-80 bg-[#e5efdc]" role="img" aria-label="Illustrated sample map with spot markers">
              <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-0 h-full w-full"><path d="M0 60Q30 40 60 55T100 45" stroke="#fff" strokeWidth="2.5" fill="none" /><path d="M35 0Q40 50 25 100" stroke="#fff" strokeWidth="2" fill="none" /><path d="M70 0Q60 40 80 100" stroke="#fff" strokeWidth="1.6" fill="none" /><ellipse cx="78" cy="22" rx="14" ry="8" fill="#bfe0ee" /><ellipse cx="18" cy="82" rx="12" ry="7" fill="#bfe0ee" /></svg>
              {SPOTS.map((s) => <button key={s.id} aria-label={`Select ${s.name}`} onClick={() => setSel(s.id)} style={{ left: `${s.x}%`, top: `${s.y}%` }} className={`absolute -translate-x-1/2 -translate-y-full transition-transform hover:scale-125 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-gold-400/60 ${sel === s.id ? "scale-125 text-gold-600" : "text-forest-700"}`}><Icon name="pin" size={30} className="fill-current" /></button>)}
              <span className="absolute bottom-2 left-2 rounded-full bg-white/80 px-3 py-1 text-xs text-forest-800">Sample map. Allow location to load a live map.</span>
            </div>)}
          <div className="flex flex-wrap items-center gap-3 border-t border-forest-900/10 p-3.5"><Icon name="pin" className="text-forest-600" /><p className="flex-1 text-sm text-forest-800">{pos ? "Showing your location (stays in your browser)." : "Allow location access to find nearby spots."}</p>
            {pos ? <a className="text-sm font-semibold underline" target="_blank" rel="noreferrer" href={`https://www.openstreetmap.org/search?query=park#map=14/${pos.lat}/${pos.lon}`}>Find parks near me ↗</a> : <Btn size="sm" onClick={locate}>Allow</Btn>}</div>
        </Card>
      </div>
      <div className="space-y-3">
        {list.length === 0 && <Card><p className="text-forest-700">No spots match your search.</p></Card>}
        {list.map((s) => (
          <Card key={s.id} className={`flex gap-4 !p-3 transition-all ${sel === s.id ? "ring-2 ring-gold-400" : ""}`}>
            <button onClick={() => setSel(s.id)} aria-label={`Highlight ${s.name}`} className="relative h-24 w-24 shrink-0 overflow-hidden rounded-xl focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-gold-400/60"><Scenic kind={s.scene} className="absolute inset-0 h-full w-full" /></button>
            <div className="min-w-0 flex-1"><h3 className="font-display text-lg font-semibold">{s.name}</h3><p className="text-xs text-forest-700">{s.km} km · {s.min} min walk · {s.type}</p><p className="mt-1 text-sm text-forest-800">{s.desc}</p>
              <Btn size="sm" variant={data.visited.includes(s.id) ? "ghost" : "primary"} className="mt-2" disabled={data.visited.includes(s.id)} onClick={() => visit(s.id)}>{data.visited.includes(s.id) ? "Visited" : "Mark visited +15 XP"}</Btn></div>
          </Card>))}
        <p className="text-xs text-forest-700">Spots and distances are sample data. Connect a places API to show real results.</p>
      </div>
    </div>
  );
}

const TABS_Quests: ("All" | "Outdoor" | "Indoor")[] = ["All", "Outdoor", "Indoor"];

function QuestCard({ q, onStart, onDone, onDel }: { q: Quest; onStart?: () => void; onDone?: () => void; onDel?: () => void }) {
  return (
    <Card className="flex flex-col overflow-hidden !p-0 transition-all hover:-translate-y-1">
      <div className="relative h-36"><Scenic kind={SCENE_FOR_STAMP[q.stamp]} className="absolute inset-0 h-full w-full" />{q.done && <span className="absolute right-3 top-3 flex items-center gap-1 rounded-full bg-forest-800 px-3 py-1 text-xs font-semibold text-gold-300"><Icon name="check" size={14} />Completed</span>}</div>
      <div className="flex flex-1 flex-col p-4">
        <h3 className="font-display text-xl font-semibold">{q.title}</h3>
        <p className="mt-0.5 text-xs text-forest-700">{q.minutes} min · {q.difficulty} · {q.setting} · +{XP_BY_DIFFICULTY[q.difficulty]} XP</p>
        <p className="mt-2 flex-1 text-sm text-forest-800">{q.description}</p>
        <p className={`mt-3 rounded-lg px-2.5 py-1.5 text-xs font-medium ${q.source === "gemma" ? "bg-forest-100 text-forest-800" : "bg-gold-400/15 text-gold-700"}`}>{q.source === "gemma" ? `Written by Gemma · ${q.model ?? "model"}${q.ms ? ` · ${(q.ms / 1000).toFixed(1)}s` : ""}` : "Demo quest (Gemma not used)"}</p>
        <div className="mt-3 flex gap-2">{onStart && <Btn size="sm" onClick={onStart}>Save quest</Btn>}{onDone && !q.done && <Btn size="sm" variant="gold" onClick={onDone}>Complete</Btn>}{onDel && <Btn size="sm" variant="ghost" aria-label={`Delete ${q.title}`} onClick={onDel}><Icon name="trash" size={16} /></Btn>}</div>
      </div>
    </Card>
  );
}

export function Quests() {
  const { data, update, award, toast } = useStore();
  const [form, setForm] = useState({ interest: data.prefs.interests[0] ?? "Birds", minutes: data.prefs.minutes, difficulty: data.prefs.difficulty as Difficulty, setting: data.prefs.setting as Setting });
  const [busy, setBusy] = useState(false);
  const [draft, setDraft] = useState<Quest | null>(null);
  const [tab, setTab] = useState<"All" | "Outdoor" | "Indoor">("All");
  const [diff, setDiff] = useState<"Any" | Difficulty>("Any");

  async function generate() {
    setBusy(true);
    try {
      const r = await fetch("/api/quests", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
      const j = (await r.json()) as { quest?: Omit<Quest, "id" | "done" | "createdAt" | "source">; source?: "gemma" | "demo"; model?: string; ms?: number; error?: string; note?: string };
      if (!r.ok || !j.quest) throw new Error(j.error ?? "Could not generate a quest");
      setDraft({ ...j.quest, id: uid(), done: false, createdAt: new Date().toISOString(), source: j.source ?? "demo", model: j.model, ms: j.ms });
      if (j.note) toast(j.note);
    } catch (e) { toast(e instanceof Error ? e.message : "Something went wrong"); }
    setBusy(false);
  }
  const save = () => { if (!draft) return; update((d) => ({ ...d, quests: [draft, ...d.quests] })); setDraft(null); toast("Quest saved. Enjoy it outside!"); };
  const done = (q: Quest) => { update((d) => ({ ...d, quests: d.quests.map((x) => (x.id === q.id ? { ...x, done: true } : x)) })); award(XP_BY_DIFFICULTY[q.difficulty], `Completed ${q.title}`, q.stamp); };
  const list = data.quests.filter((q) => (tab === "All" || q.setting === tab) && (diff === "Any" || q.difficulty === diff));

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <Card>
        <div className="flex items-center gap-3"><span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-gold-300 to-gold-500 text-forest-950"><Icon name="sparkles" /></span><div><h2 className="font-display text-xl font-semibold">Your AI assistant · Gemma</h2><p className="text-sm text-forest-700">Tell Gemma what you feel like doing. The API key stays on the server.</p></div></div>
        <div className="mt-2 grid gap-x-4 sm:grid-cols-2 lg:grid-cols-4">
          <div><label className={labelCls} htmlFor="qi">Interest</label><select id="qi" className={field} value={form.interest} onChange={(e) => setForm({ ...form, interest: e.target.value })}>{INTERESTS.map((i) => <option key={i.name}>{i.name}</option>)}</select></div>
          <div><label className={labelCls} htmlFor="qm">Time</label><select id="qm" className={field} value={form.minutes} onChange={(e) => setForm({ ...form, minutes: Number(e.target.value) })}>{[5, 15, 30, 60].map((m) => <option key={m} value={m}>{m} minutes</option>)}</select></div>
          <div><label className={labelCls} htmlFor="ql">Difficulty</label><select id="ql" className={field} value={form.difficulty} onChange={(e) => setForm({ ...form, difficulty: e.target.value as Difficulty })}>{["Easy", "Medium", "Hard"].map((m) => <option key={m}>{m}</option>)}</select></div>
          <div><label className={labelCls} htmlFor="qs">Setting</label><select id="qs" className={field} value={form.setting} onChange={(e) => setForm({ ...form, setting: e.target.value as Setting })}>{["Outdoor", "Indoor"].map((m) => <option key={m}>{m}</option>)}</select></div>
        </div>
        <Btn className="mt-5" variant="gold" disabled={busy} onClick={generate}><Icon name="sparkles" size={18} />{busy ? "Gemma is thinking…" : "Generate personalised quest"}</Btn>
        <p className="mt-2 text-xs text-forest-700">Choose safe, accessible places. Indoor quests count too.</p>
      </Card>
      {draft && <div className="max-w-sm animate-fade-up"><p className="mb-2 text-sm font-semibold text-forest-700">New suggestion</p><QuestCard q={draft} onStart={save} /></div>}
      <div className="flex flex-wrap items-center gap-3"><h2 className="font-display text-2xl font-semibold">Your quests</h2><Tabs items={TABS_Quests} value={tab} onChange={setTab} />
        <label className="sr-only" htmlFor="df">Filter by difficulty</label><select id="df" value={diff} onChange={(e) => setDiff(e.target.value as "Any" | Difficulty)} className="rounded-xl border border-forest-900/15 bg-white px-3 py-1.5 text-sm"><option>Any</option><option>Easy</option><option>Medium</option><option>Hard</option></select></div>
      {list.length === 0 ? <Card><p className="text-forest-700">No quests here yet. Generate one above.</p></Card> :
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{list.map((q) => <QuestCard key={q.id} q={q} onDone={() => done(q)} onDel={() => update((d) => ({ ...d, quests: d.quests.filter((x) => x.id !== q.id) }))} />)}</div>}
    </div>
  );
}

export function Bingo() {
  const { data, update, award, toast } = useStore();
  const { tiles, done } = data.bingo;
  const n = done.filter(Boolean).length;
  const reward = [...BADGES].reverse().find((b) => b.test(data));
  const toggle = (i: number) => {
    const next = done.map((v, k) => (k === i ? !v : v));
    const line = hasLine(next);
    update((d) => ({ ...d, bingo: { ...d.bingo, done: next, lineBonus: d.bingo.lineBonus || line } }));
    if (!done[i]) {
      award(10, `Found: ${tiles[i]}`);
      if (line && !data.bingo.lineBonus) setTimeout(() => award(50, "Bingo line!", "bingo"), 300);
    }
  };
  const fresh = () => { update((d) => ({ ...d, bingo: { tiles: shuffledTiles(), done: Array(9).fill(false), lineBonus: false } })); toast("New board ready."); };
  return (
    <div className="mx-auto grid max-w-5xl gap-6 lg:grid-cols-[1.5fr_1fr]">
      <Card>
        <div className="mb-4 flex items-center justify-between"><p className="text-sm text-forest-700">Tap a square when you find it in real life.</p><Btn size="sm" variant="ghost" onClick={fresh}>New board</Btn></div>
        <div className="grid grid-cols-3 gap-3" role="group" aria-label="Nature bingo board">
          {tiles.map((t, i) => { const ic = BINGO_POOL.find((b) => b.t === t)?.i ?? "leaf"; return (
            <button key={t + i} aria-pressed={done[i]} onClick={() => toggle(i)} className={`group relative flex aspect-square flex-col items-center justify-center gap-2 rounded-2xl border-2 p-2 text-center text-sm font-semibold transition-all duration-300 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-gold-400/60 ${done[i] ? "animate-pop border-gold-400 bg-gradient-to-br from-forest-600 to-forest-800 text-cream-50 shadow-lift" : "border-forest-900/10 bg-white text-forest-800 shadow-sm hover:-translate-y-1 hover:border-forest-400 hover:shadow-md"}`}>
              <Icon name={done[i] ? "check" : ic} size={30} className={done[i] ? "text-gold-300" : "text-forest-600 group-hover:scale-110"} /><span>{t}</span></button>); })}
        </div>
      </Card>
      <div className="space-y-5">
        <Card className="text-center"><h3 className="font-display text-lg font-semibold">Progress</h3><div className="mt-3"><Ring value={(n / 9) * 100} label={`${n}/9`} sub="completed" /></div><p className="mt-3 text-sm text-forest-700">{hasLine(done) ? "Line complete! Bonus XP earned." : "Complete any row, column or diagonal for +50 XP."}</p></Card>
        <Card className="text-center"><h3 className="font-display text-lg font-semibold">Current reward</h3><div className="mx-auto mt-3 flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-gold-300 to-gold-600 text-forest-950 shadow-lg"><Icon name={reward?.icon ?? "leaf"} size={36} /></div><p className="mt-3 font-display text-lg font-semibold">{reward?.name ?? "No badge yet"}</p><p className="text-sm text-forest-700">{reward?.desc ?? "Find your first square to start."}</p><p className="mt-3 flex items-center justify-center gap-1.5 text-sm font-semibold text-forest-800"><Icon name="flame" size={16} className="text-gold-600" />{data.streak}-day streak</p></Card>
        <p className="text-center text-sm italic text-forest-700">“Nature is not a place to visit, it is home.”</p>
      </div>
    </div>
  );
}

const SCENES: SceneKind[] = ["forest", "lake", "sunrise", "meadow", "mountain"];

export function Journal() {
  const { data, update, award, upload, toast } = useStore();
  const [edit, setEdit] = useState<JournalEntry | "new" | null>(null);
  const [title, setTitle] = useState(""), [notes, setNotes] = useState(""), [scene, setScene] = useState<SceneKind>("forest");
  const [file, setFile] = useState<File | null>(null), [busy, setBusy] = useState(false);

  const open = (e: JournalEntry | "new") => { setEdit(e); setFile(null); if (e === "new") { setTitle(""); setNotes(""); setScene("forest"); } else { setTitle(e.title); setNotes(e.notes); setScene(e.scene); } };
  async function save(ev: FormEvent) {
    ev.preventDefault();
    if (!title.trim()) return toast("Please add a title.");
    setBusy(true);
    try {
      let image = edit && edit !== "new" ? edit.image : undefined;
      if (file) image = await upload(file);
      if (edit === "new" || edit === null) {
        const first = data.journal.length === 0;
        update((d) => ({ ...d, journal: [{ id: uid(), title: title.trim(), notes: notes.trim(), image, scene, date: new Date().toISOString() }, ...d.journal] }));
        award(10, `Added journal entry: ${title.trim()}`, first ? "journal" : undefined);
      } else {
        const id = edit.id;
        update((d) => ({ ...d, journal: d.journal.map((j) => (j.id === id ? { ...j, title: title.trim(), notes: notes.trim(), image, scene } : j)) }));
        toast("Entry updated.");
      }
      setEdit(null);
    } catch (e) { toast(e instanceof Error ? e.message : "Could not save entry"); }
    setBusy(false);
  }
  const del = (id: string) => { if (confirm("Delete this entry?")) update((d) => ({ ...d, journal: d.journal.filter((j) => j.id !== id) })); };

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div className="flex items-center justify-between"><p className="text-forest-700">{data.journal.length} {data.journal.length === 1 ? "entry" : "entries"}. Photos are private to your account.</p><Btn onClick={() => open("new")}><Icon name="plus" size={18} />New entry</Btn></div>
      {data.journal.length === 0 ? <Card className="py-14 text-center"><span className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-forest-100 text-forest-600"><Icon name="book" size={30} /></span><p className="mt-3 font-display text-xl font-semibold">Your journal is empty</p><p className="text-forest-700">Capture your first moment outside.</p></Card> :
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{data.journal.map((j) => (
          <Card key={j.id} className="overflow-hidden !p-0 transition-all hover:-translate-y-1"><div className="relative h-44">{j.image ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={j.image} alt={`Photo for ${j.title}`} className="h-full w-full object-cover" /> : <Scenic kind={j.scene} className="absolute inset-0 h-full w-full" />}</div>
            <div className="p-4"><h3 className="font-display text-lg font-semibold">{j.title}</h3><p className="text-xs text-forest-700">{new Date(j.date).toLocaleDateString(undefined, { dateStyle: "medium" })}</p><p className="mt-2 line-clamp-3 text-sm text-forest-800">{j.notes}</p>
              <div className="mt-3 flex gap-2"><Btn size="sm" variant="ghost" aria-label={`Edit ${j.title}`} onClick={() => open(j)}><Icon name="edit" size={16} /></Btn><Btn size="sm" variant="ghost" aria-label={`Delete ${j.title}`} onClick={() => del(j.id)}><Icon name="trash" size={16} /></Btn></div></div></Card>))}</div>}
      {edit && (
        <Modal title={edit === "new" ? "New journal entry" : "Edit entry"} onClose={() => setEdit(null)}>
          <form onSubmit={save}>
            <label className={labelCls} htmlFor="jt">Title</label><input id="jt" autoFocus className={field} value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Morning hike" />
            <label className={labelCls} htmlFor="jn">Notes</label><textarea id="jn" rows={4} className={field} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="What did you notice?" />
            <label className={labelCls} htmlFor="jp">Photo (optional)</label><input id="jp" type="file" accept="image/*" className={field} onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
            <label className={labelCls} htmlFor="js">Illustration (used when there is no photo)</label><select id="js" className={field} value={scene} onChange={(e) => setScene(e.target.value as SceneKind)}>{SCENES.map((s) => <option key={s}>{s}</option>)}</select>
            <div className="mt-6 flex gap-3"><Btn type="submit" variant="gold" disabled={busy}>{busy ? "Saving…" : "Save entry"}</Btn><Btn type="button" variant="ghost" onClick={() => setEdit(null)}>Cancel</Btn></div>
          </form>
        </Modal>)}
    </div>
  );
}

export function Passport() {
  const { data } = useStore();
  const got = STAMPS.filter((s) => data.stamps.includes(s.key)).length;
  return (
    <div className="mx-auto max-w-5xl">
      <div className="grid overflow-hidden rounded-3xl border border-gold-600/30 bg-cream-50 shadow-paper md:grid-cols-[320px_1fr]">
        <div className="relative bg-gradient-to-br from-forest-800 to-forest-950 p-7 text-center text-cream-100">
          <p className="text-xs uppercase tracking-[.25em] text-gold-300">Nature Bingo</p><h2 className="mt-1 font-display text-3xl font-semibold text-gold-300">My Nature Passport</h2>
          <div className="mt-6 flex justify-center"><Avatar src={data.profile.avatar} name={data.profile.name} size={96} /></div>
          <p className="mt-3 font-display text-xl font-semibold text-cream-50">{data.profile.name}</p><p className="text-sm text-forest-100/80">Level {levelOf(data.xp)} · {levelName(data.xp)}</p>
          <div className="mt-5 text-left"><div className="mb-1 flex justify-between text-xs"><span>{data.xp % 100} / 100 XP</span><span>Level {levelOf(data.xp) + 1}</span></div><Bar value={data.xp % 100} label="XP to next level" /></div>
          <p className="mt-5 rounded-xl bg-white/10 p-3 text-sm"><b className="text-gold-300">{got}/{STAMPS.length}</b> stamps collected</p>
        </div>
        <div className="p-6 sm:p-8">
          <h3 className="font-display text-xl font-semibold">Collected stamps</h3><p className="text-sm text-forest-700">Complete quests and visit new places to earn each stamp.</p>
          <ul className="mt-5 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">{STAMPS.map((s) => { const on = data.stamps.includes(s.key); return (
            <li key={s.key} className={`flex flex-col items-center rounded-2xl border-2 p-4 text-center transition-all ${on ? "border-gold-400 bg-gradient-to-b from-gold-300/25 to-transparent shadow-md" : "border-dashed border-forest-900/20 text-forest-900/45"}`}>
              <span className={`flex h-14 w-14 items-center justify-center rounded-full border-4 ${on ? "border-gold-500 bg-forest-700 text-gold-300" : "border-forest-900/20"}`}><Icon name={on ? s.icon : "lock"} size={24} /></span>
              <span className="mt-2 text-sm font-semibold">{s.label}</span><span className="text-xs">{on ? "Collected" : s.hint}</span></li>); })}</ul>
        </div>
      </div>
    </div>
  );
}

const MILESTONES = [100, 250, 500, 750, 1000];
const TABS_Achievements = ["Badges", "Milestones"] as const;

export function Achievements() {
  const { data } = useStore();
  const [tab, setTab] = useState<(typeof TABS_Achievements)[number]>("Badges");
  const unlocked = BADGES.filter((b) => b.test(data)).length;
  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div className="grid gap-4 sm:grid-cols-3">{[["award", data.xp, "Total XP"], ["flame", data.streak, "Day streak"], ["trophy", `${unlocked}/${BADGES.length}`, "Badges unlocked"]].map(([i, n, l]) => (
        <Card key={String(l)} className="flex items-center gap-4"><span className="flex h-12 w-12 items-center justify-center rounded-xl bg-forest-100 text-forest-700"><Icon name={i as "award"} size={24} /></span><div><div className="font-display text-3xl font-semibold">{n}</div><div className="text-sm text-forest-700">{l}</div></div></Card>))}</div>
      <Tabs items={[...TABS_Achievements]} value={tab} onChange={setTab} />
      {tab === "Badges" ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{BADGES.map((b) => { const on = b.test(data); return (
          <Card key={b.id} className={`flex items-center gap-4 transition-all ${on ? "border-gold-400/70" : "opacity-60"}`}>
            <span className={`flex h-16 w-16 shrink-0 items-center justify-center rounded-full ${on ? "bg-gradient-to-br from-gold-300 to-gold-600 text-forest-950 shadow-lg" : "bg-forest-900/10 text-forest-900/50"}`}><Icon name={on ? b.icon : "lock"} size={28} /></span>
            <div><h3 className="font-display text-lg font-semibold">{b.name}</h3><p className="text-sm text-forest-700">{b.desc}</p><p className="mt-1 text-xs font-semibold">{on ? "Unlocked" : "Locked"}</p></div></Card>); })}</div>
      ) : (
        <Card><ul className="space-y-5">{MILESTONES.map((m) => (<li key={m}><div className="mb-1 flex justify-between text-sm font-semibold"><span>{m} XP milestone</span><span>{Math.min(data.xp, m)} / {m}</span></div><Bar value={(data.xp / m) * 100} label={`${m} XP milestone`} /></li>))}</ul></Card>)}
    </div>
  );
}

const TABS_Community = ["Challenges", "Feed", "Leaderboard"] as const;

export function Community() {
  const { data, update, award, toast } = useStore();
  const [tab, setTab] = useState<(typeof TABS_Community)[number]>("Challenges");
  const [text, setText] = useState("");
  const join = (id: string) => update((d) => ({ ...d, joined: d.joined.includes(id) ? d.joined.filter((x) => x !== id) : [...d.joined, id] }));
  const post = () => {
    if (!text.trim()) return toast("Write something first.");
    update((d) => ({ ...d, posts: [{ id: uid(), author: d.profile.name, text: text.trim(), date: new Date().toISOString(), mine: true }, ...d.posts] }));
    award(5, "Shared a moment"); setText("");
  };
  const board = [...LEADERBOARD, { name: data.profile.name + " (you)", xp: data.xp }].sort((a, b) => b.xp - a.xp);
  return (
    <div className="mx-auto max-w-5xl space-y-5">
      <Tabs items={[...TABS_Community]} value={tab} onChange={setTab} />
      <p className="text-xs text-forest-700">Sample community: other members are illustrative. Your posts and challenge progress are saved to your account only.</p>
      {tab === "Challenges" && <div className="grid gap-5 md:grid-cols-3">{CHALLENGES.map((c) => { const on = data.joined.includes(c.id); const p = Math.min(c.target, c.progress(data)); return (
        <Card key={c.id} className="overflow-hidden !p-0"><div className="relative h-32"><Scenic kind={c.scene} className="absolute inset-0 h-full w-full" /></div>
          <div className="p-4"><h3 className="font-display text-lg font-semibold">{c.title}</h3><p className="text-sm text-forest-700">{c.desc}</p>
            {on && <div className="mt-3"><div className="mb-1 flex justify-between text-xs font-semibold"><span>Progress</span><span>{p}/{c.target} {c.unit}</span></div><Bar value={(p / c.target) * 100} label={`${c.title} progress`} /></div>}
            <Btn size="sm" variant={on ? "ghost" : "primary"} className="mt-4" aria-pressed={on} onClick={() => join(c.id)}>{on ? "Leave challenge" : "Join challenge"}</Btn></div></Card>); })}</div>}
      {tab === "Feed" && <div className="space-y-4">
        <Card><label htmlFor="post" className="sr-only">Share a moment</label><textarea id="post" rows={3} className={field} placeholder="Share what you noticed outside today…" value={text} onChange={(e) => setText(e.target.value)} /><Btn className="mt-3" onClick={post}>Post (+5 XP)</Btn></Card>
        {[...data.posts.map((p) => ({ id: p.id, author: p.author, text: p.text, when: new Date(p.date).toLocaleDateString(), mine: true })), ...FEED.map((f) => ({ id: f.id, author: f.author, text: f.text, when: f.daysAgo === 0 ? "Today" : `${f.daysAgo}d ago`, mine: false }))].map((p) => (
          <Card key={p.id} className="flex gap-3"><Avatar name={p.author} size={40} src={p.mine ? data.profile.avatar : undefined} /><div><p className="text-sm"><b>{p.author}</b> <span className="text-forest-700">· {p.when}</span></p><p className="mt-1 text-forest-800">{p.text}</p></div></Card>))}</div>}
      {tab === "Leaderboard" && <Card><ol className="divide-y divide-forest-900/10">{board.map((r, i) => (
        <li key={r.name} className={`flex items-center gap-4 py-3 ${r.name.endsWith("(you)") ? "font-bold" : ""}`}><span className={`flex h-8 w-8 items-center justify-center rounded-full text-sm ${i === 0 ? "bg-gold-400 text-forest-950" : "bg-forest-100 text-forest-800"}`}>{i === 0 ? <Icon name="trophy" size={16} /> : i + 1}</span><span className="flex-1">{r.name}</span><span className="font-semibold text-forest-700">{r.xp} XP</span></li>))}</ol></Card>}
    </div>
  );
}

const fmt = (m: number) => `${Math.floor(m / 60)}h ${m % 60}m`;

export function ScreenTime() {
  const { data, update, toast } = useStore();
  const days = lastDays(7);
  const vals = days.map((d) => data.screen[d.key] ?? 0);
  const logged = vals.filter((v) => v > 0);
  const total = vals.reduce((a, b) => a + b, 0);
  const avg = logged.length ? Math.round(total / logged.length) : 0;
  const under = days.filter((d) => (data.screen[d.key] ?? 0) > 0 && (data.screen[d.key] ?? 0) <= data.goal).length;
  const outdoor = data.quests.filter((q) => q.done && q.setting === "Outdoor").reduce((a, q) => a + q.minutes, 0);
  const max = Math.max(data.goal, ...vals, 1);
  const today = data.screen[dayKey()] ?? 0;
  const [mins, setMins] = useState(today ? String(today) : ""), [goal, setGoal] = useState(String(data.goal));
  const save = (e: FormEvent) => {
    e.preventDefault();
    const m = Number(mins), g = Number(goal);
    if (!Number.isFinite(m) || m < 0 || m > 1440 || !Number.isFinite(g) || g < 10 || g > 1440) return toast("Enter minutes between 0 and 1440 (goal at least 10).");
    update((d) => ({ ...d, goal: g, screen: { ...d.screen, [dayKey()]: m } })); toast("Saved.");
  };
  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div className="grid gap-5 lg:grid-cols-3">
        <Card><h2 className="font-display text-lg font-semibold">Log today</h2><p className="text-sm text-forest-700">A website can only know the minutes you enter. Device-wide tracking needs a native app or extension.</p>
          <form onSubmit={save}><label className={labelCls} htmlFor="m">Screen minutes today</label><input id="m" type="number" min={0} max={1440} className={field} value={mins} onChange={(e) => setMins(e.target.value)} /><label className={labelCls} htmlFor="g">Daily goal (minutes)</label><input id="g" type="number" min={10} max={1440} className={field} value={goal} onChange={(e) => setGoal(e.target.value)} /><Btn type="submit" className="mt-4">Save</Btn></form></Card>
        <Card className="flex flex-col items-center justify-center text-center"><h2 className="font-display text-lg font-semibold">Goal progress</h2><div className="mt-3"><Ring value={(today / data.goal) * 100} label={`${Math.round((today / data.goal) * 100)}%`} sub={`${fmt(today)} / ${fmt(data.goal)}`} size={150} /></div></Card>
        <Card><h2 className="font-display text-lg font-semibold">Weekly summary</h2><dl className="mt-3 space-y-3 text-sm">{[["Total this week", fmt(total)], ["Average per logged day", logged.length ? fmt(avg) : "n/a"], ["Days within goal", `${under} of ${logged.length}`], ["Outdoor quest minutes", `${outdoor} min`]].map(([k, v]) => <div key={k} className="flex justify-between border-b border-forest-900/10 pb-2"><dt className="text-forest-700">{k}</dt><dd className="font-semibold">{v}</dd></div>)}</dl></Card>
      </div>
      <Card><h2 className="font-display text-lg font-semibold">Daily usage</h2>
        <div className="relative mt-5 flex h-52 items-end gap-3" role="img" aria-label={`Screen minutes: ${days.map((d, i) => `${d.label} ${vals[i]}`).join(", ")}`}>
          <div className="absolute inset-x-0 border-t border-dashed border-gold-500" style={{ bottom: `${(data.goal / max) * 100}%` }} />
          {days.map((d, i) => (<div key={d.key} className="flex flex-1 flex-col items-center justify-end gap-1"><span className="text-xs font-semibold text-forest-700">{vals[i] || ""}</span><div className={`w-full rounded-t-lg transition-all duration-700 ${vals[i] > data.goal ? "bg-gold-500" : "bg-forest-500"}`} style={{ height: `${(vals[i] / max) * 100}%`, minHeight: vals[i] ? 4 : 0 }} /><span className="text-xs text-forest-700">{d.label}</span></div>))}</div></Card>
      <Card className="flex items-start gap-3 bg-forest-100"><Icon name="sparkles" className="mt-0.5 text-forest-700" /><p className="text-sm text-forest-800">{today === 0 ? "Log today's minutes to get a tip." : today <= data.goal ? "You are within your goal today. A short outdoor quest keeps the balance going." : `You are ${today - data.goal} minutes over today's goal. A 5-minute quest is a good reset.`}</p></Card>
    </div>
  );
}

interface Health { provider: string; model: string | null; reachable: boolean | null }

export function Settings() {
  const { data, update, upload, toast, signOut, session } = useStore();
  const router = useRouter();
  const [name, setName] = useState(data.profile.name), [bio, setBio] = useState(data.profile.bio);
  const [health, setHealth] = useState<Health | null>(null);
  useEffect(() => { fetch("/api/quests").then((r) => r.json()).then((j: Health) => setHealth(j)).catch(() => setHealth(null)); }, []);
  const pr = data.prefs;
  const setPref = (patch: Partial<typeof pr>) => update((d) => ({ ...d, prefs: { ...d.prefs, ...patch } }));
  const toggle = (k: "reduceMotion" | "largeText" | "reminders", label: string) => (
    <label key={k} className="flex cursor-pointer items-center justify-between gap-4 rounded-xl border border-forest-900/10 bg-white px-4 py-3"><span className="font-medium">{label}</span><input type="checkbox" role="switch" checked={pr[k]} onChange={(e) => setPref(k === "reduceMotion" ? { reduceMotion: e.target.checked } : k === "largeText" ? { largeText: e.target.checked } : { reminders: e.target.checked })} className="h-5 w-10 cursor-pointer accent-forest-600" /></label>);
  async function photo(f?: File) {
    if (!f) return;
    try { const url = await upload(f, 256); update((d) => ({ ...d, profile: { ...d.profile, avatar: url } })); toast("Profile photo updated."); } catch (e) { toast(e instanceof Error ? e.message : "Upload failed"); }
  }
  const exportData = () => { const b = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }); const a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = "nature-bingo-data.json"; a.click(); URL.revokeObjectURL(a.href); };
  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <Card><h2 className="font-display text-xl font-semibold">Profile</h2>
        <div className="mt-4 flex items-center gap-4"><Avatar src={data.profile.avatar} name={data.profile.name} size={72} /><label className="cursor-pointer rounded-xl border border-forest-900/20 bg-white px-4 py-2 text-sm font-semibold focus-within:ring-4 focus-within:ring-gold-400/50 hover:bg-forest-50"><Icon name="upload" size={16} className="mr-2 inline" />Change photo<input type="file" accept="image/*" className="sr-only" onChange={(e) => void photo(e.target.files?.[0])} /></label></div>
        <label className={labelCls} htmlFor="n">Display name</label><input id="n" className={field} value={name} onChange={(e) => setName(e.target.value)} />
        <label className={labelCls} htmlFor="b">Bio</label><textarea id="b" rows={2} className={field} value={bio} onChange={(e) => setBio(e.target.value)} />
        <Btn className="mt-4" onClick={() => { update((d) => ({ ...d, profile: { ...d.profile, name: name.trim() || d.profile.name, bio } })); toast("Profile saved."); }}>Save changes</Btn></Card>
      <Card><h2 className="font-display text-xl font-semibold">Preferences</h2>
        <p className="mt-3 text-sm font-semibold text-forest-800">Interests</p><div className="mt-2 flex flex-wrap gap-2">{INTERESTS.map((i) => { const on = pr.interests.includes(i.name); return <button key={i.name} aria-pressed={on} onClick={() => setPref({ interests: on ? pr.interests.filter((x) => x !== i.name) : [...pr.interests, i.name] })} className={`rounded-full border px-4 py-1.5 text-sm font-semibold focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-gold-400/50 ${on ? "border-forest-700 bg-forest-700 text-cream-50" : "border-forest-900/15 bg-white"}`}>{i.name}</button>; })}</div>
        <div className="mt-5 space-y-3">{toggle("reduceMotion", "Reduce motion and animations")}{toggle("largeText", "Larger text")}{toggle("reminders", "Gentle daily reminders (in-app)")}</div></Card>
      <Card><h2 className="font-display text-xl font-semibold">AI and backend status</h2>
        <ul className="mt-3 space-y-2 text-sm">
          <li className="flex items-center gap-2"><span className={`h-2.5 w-2.5 rounded-full ${health && health.provider !== "demo" && health.reachable !== false ? "bg-emerald-500" : "bg-gold-500"}`} />{health ? (health.provider === "demo" ? "Gemma: not configured. Demo fallback is active." : `Gemma via ${health.provider} · ${health.model}${health.reachable === false ? " (unreachable, using fallback)" : ""}`) : "Checking Gemma…"}</li>
          <li className="flex items-center gap-2"><span className={`h-2.5 w-2.5 rounded-full ${isConfigured ? "bg-emerald-500" : "bg-gold-500"}`} />{isConfigured ? "Supabase: connected for auth, data and photo storage." : "Supabase: not configured. Running in local demo mode."}</li>
        </ul><p className="mt-3 text-xs text-forest-700">API keys are only read on the server. See README.md to configure them.</p></Card>
      <Card><h2 className="font-display text-xl font-semibold">Data and privacy</h2><p className="mt-1 text-sm text-forest-700">{session?.demo ? "Demo data lives in this browser only." : "Your data is stored in your Supabase account."}</p>
        <div className="mt-4 flex flex-wrap gap-3"><Btn variant="ghost" onClick={exportData}><Icon name="download" size={16} />Export my data</Btn>
          <Btn variant="ghost" onClick={() => { if (confirm("Reset all progress? This cannot be undone.")) { update(() => newUserData(data.profile.name)); toast("Progress reset."); } }}>Reset progress</Btn>
          <Btn variant="danger" onClick={async () => { await signOut(); router.push("/"); }}><Icon name="logout" size={16} />Sign out</Btn></div></Card>
    </div>
  );
}
