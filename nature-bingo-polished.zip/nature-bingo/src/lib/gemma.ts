// SERVER-ONLY helpers. Never import this file from a client component.
import type { Difficulty, Setting, StampKey } from "./app";

export type Provider = "ollama" | "google" | "demo";
export const STAMP_KEYS: StampKey[] = ["forest", "bird", "plant", "mountain", "sky", "water"];

export function provider(): Provider {
  const p = process.env.GEMMA_PROVIDER;
  if (p === "ollama" && process.env.OLLAMA_URL) return "ollama";
  if (p === "google" && process.env.GOOGLE_AI_API_KEY) return "google";
  return "demo";
}
export function modelName(): string {
  return process.env.GEMMA_MODEL || (provider() === "ollama" ? "gemma3:4b" : "gemma-3-27b-it");
}

export async function callGemma(prompt: string): Promise<{ text: string; model: string }> {
  const model = modelName();
  if (provider() === "ollama") {
    const r = await fetch(`${process.env.OLLAMA_URL}/api/generate`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ model, prompt, stream: false, format: "json", options: { temperature: 0.8 } }),
      signal: AbortSignal.timeout(90_000),
    });
    if (!r.ok) throw new Error(`Ollama returned ${r.status}`);
    const j = (await r.json()) as { response?: string };
    return { text: j.response ?? "", model };
  }
  const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-goog-api-key": process.env.GOOGLE_AI_API_KEY as string },
    body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { temperature: 0.8 } }),
    signal: AbortSignal.timeout(60_000),
  });
  if (!r.ok) throw new Error(`Google AI returned ${r.status}`);
  const j = (await r.json()) as { candidates?: { content?: { parts?: { text?: string }[] } }[] };
  return { text: j.candidates?.[0]?.content?.parts?.[0]?.text ?? "", model };
}

export interface QuestInput { interest: string; minutes: number; difficulty: Difficulty; setting: Setting }
export interface QuestOut { title: string; description: string; minutes: number; difficulty: Difficulty; setting: Setting; stamp: StampKey }

export function buildPrompt(i: QuestInput): string {
  return `You are a friendly nature-activity coach. Create ONE short, real-world nature quest.
Interest: ${i.interest}. Time available: ${i.minutes} minutes. Difficulty: ${i.difficulty}. Setting: ${i.setting}.
Rules: safe, accessible, the phone stays in the pocket, no dangerous places, no touching wildlife.
Reply with ONLY JSON: {"title":"2-4 words","description":"max 2 short sentences","stamp":"one of: ${STAMP_KEYS.join(", ")}"}`;
}

export function parseQuest(text: string, i: QuestInput): QuestOut {
  const a = text.indexOf("{"), b = text.lastIndexOf("}");
  if (a < 0 || b < a) throw new Error("No JSON in model reply");
  const o = JSON.parse(text.slice(a, b + 1)) as { title?: unknown; description?: unknown; stamp?: unknown };
  if (typeof o.title !== "string" || typeof o.description !== "string" || !o.title.trim()) throw new Error("Incomplete JSON");
  const stamp = STAMP_KEYS.includes(o.stamp as StampKey) ? (o.stamp as StampKey) : stampFor(i.interest);
  return { title: o.title.trim().slice(0, 60), description: o.description.trim().slice(0, 300), minutes: i.minutes, difficulty: i.difficulty, setting: i.setting, stamp };
}

const T: Record<string, [string, string, string, StampKey]> = {
  Birds: ["Listen and Count", "Stand still and note every different bird call you hear.", "Open a window and note the bird sounds you can hear.", "bird"],
  Plants: ["Leaf Collection", "Find five different leaf shapes and photograph them.", "Study a houseplant and sketch its leaf veins.", "plant"],
  Photography: ["Light and Shadow", "Photograph three shadows made by plants or trees.", "Photograph light patterns coming through a window.", "sky"],
  Hiking: ["Trail Discovery", "Walk a nearby path and notice three changes in the landscape.", "Walk around your home noticing five different textures.", "mountain"],
  Wildlife: ["Quiet Observer", "Sit quietly for a few minutes and note every creature you spot.", "Watch the window ledge or garden for visitors.", "forest"],
  Gardening: ["Soil and Sprout", "Find a patch of soil and look for signs of new growth.", "Check a houseplant and give it a gentle look-over.", "plant"],
  Mindfulness: ["Five Senses Pause", "Name five things you see, four you hear and three you feel.", "Sit by a window and slowly name five things you can see.", "water"],
};
export function stampFor(interest: string): StampKey { return (T[interest]?.[3]) ?? "forest"; }
export function demoQuest(i: QuestInput): QuestOut {
  const t = T[i.interest] ?? T.Hiking;
  const hard = i.difficulty === "Hard" ? " Repeat it at a different time of day and compare." : i.difficulty === "Medium" ? " Write one sentence about what surprised you." : "";
  return { title: t[0], description: (i.setting === "Outdoor" ? t[1] : t[2]) + hard, minutes: i.minutes, difficulty: i.difficulty, setting: i.setting, stamp: t[3] };
}
