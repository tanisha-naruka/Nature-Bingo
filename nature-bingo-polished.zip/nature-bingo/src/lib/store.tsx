"use client";
import { createContext, ReactNode, useCallback, useContext, useEffect, useRef, useState } from "react";
import { createClient, SupabaseClient } from "@supabase/supabase-js";
import { dayKey, newUserData, seedDemo, UserData } from "./app";

const sbUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const sbKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
/** True when both Supabase env vars are set. Otherwise the app runs in local demo mode. */
export const isConfigured = Boolean(sbUrl && sbKey);
const supabase: SupabaseClient | null = isConfigured ? createClient(sbUrl as string, sbKey as string) : null;

export interface Session { id: string; email: string; demo: boolean }
interface Ctx {
  ready: boolean; session: Session | null; data: UserData; toastMsg: string;
  update: (fn: (d: UserData) => UserData) => void;
  award: (xp: number, text: string, stamp?: string) => void;
  startDemo: (name: string, avatar?: File | null) => Promise<void>;
  signUp: (email: string, password: string, name: string, avatar?: File | null) => Promise<string | null>;
  signIn: (email: string, password: string) => Promise<string | null>;
  oauth: (provider: "google" | "github") => Promise<void>;
  signOut: () => Promise<void>;
  upload: (file: File, max?: number) => Promise<string>;
  toast: (m: string) => void;
}
const C = createContext<Ctx | null>(null);
export function useStore(): Ctx {
  const c = useContext(C);
  if (!c) throw new Error("StoreProvider is missing");
  return c;
}

function resize(file: File, max: number): Promise<Blob> {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onerror = () => rej(new Error("Could not read file"));
    r.onload = () => {
      const im = new Image();
      im.onerror = () => rej(new Error("Not a valid image"));
      im.onload = () => {
        const k = Math.min(1, max / Math.max(im.width, im.height));
        const c = document.createElement("canvas");
        c.width = Math.round(im.width * k); c.height = Math.round(im.height * k);
        c.getContext("2d")?.drawImage(im, 0, 0, c.width, c.height);
        c.toBlob((b) => (b ? res(b) : rej(new Error("Could not process image"))), "image/jpeg", 0.8);
      };
      im.src = String(r.result);
    };
    r.readAsDataURL(file);
  });
}
const blobToUrl = (b: Blob) => new Promise<string>((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result)); r.onerror = () => rej(new Error("read")); r.readAsDataURL(b); });

function merge(raw: Partial<UserData> | null, name: string): UserData {
  const base = newUserData(name);
  if (!raw) return base;
  return { ...base, ...raw, profile: { ...base.profile, ...raw.profile }, prefs: { ...base.prefs, ...raw.prefs }, bingo: { ...base.bingo, ...raw.bingo } };
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [session, setSessionState] = useState<Session | null>(null);
  const [data, setData] = useState<UserData>(() => newUserData("Explorer"));
  const [toastMsg, setToastMsg] = useState("");
  const loaded = useRef(false);
  const sref = useRef<Session | null>(null);
  const pendingAvatar = useRef<File | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const setSession = (s: Session | null) => { sref.current = s; setSessionState(s); };
  const toast = useCallback((m: string) => {
    setToastMsg(m);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setToastMsg(""), 3500);
  }, []);

  const upload = useCallback(async (file: File, max = 720) => {
    const blob = await resize(file, max);
    const s = sref.current;
    if (supabase && s && !s.demo) {
      const path = `${s.id}/${Date.now()}.jpg`;
      const { error } = await supabase.storage.from("media").upload(path, blob, { contentType: "image/jpeg" });
      if (!error) return supabase.storage.from("media").getPublicUrl(path).data.publicUrl;
    }
    return blobToUrl(blob);
  }, []);

  const load = useCallback(async (s: Session, name: string) => {
    let raw: Partial<UserData> | null = null;
    if (s.demo) {
      try { const t = localStorage.getItem("nb:data:" + s.id); raw = t ? (JSON.parse(t) as Partial<UserData>) : null; } catch { raw = null; }
    } else if (supabase) {
      const { data: row } = await supabase.from("user_state").select("data").eq("id", s.id).maybeSingle();
      raw = (row?.data as Partial<UserData> | undefined) ?? null;
    }
    let d = merge(raw, name);
    if (!raw && s.demo) d = seedDemo(d);
    loaded.current = false; setData(d); loaded.current = true;
    if (pendingAvatar.current && !s.demo) {
      const f = pendingAvatar.current; pendingAvatar.current = null;
      try { const url = await upload(f, 256); setData((x) => ({ ...x, profile: { ...x.profile, avatar: url } })); } catch { /* ignore */ }
    }
  }, [upload]);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const t = localStorage.getItem("nb:session");
        if (t) { const s = JSON.parse(t) as Session; setSession(s); await load(s, "Explorer"); if (alive) setReady(true); return; }
      } catch { /* ignore */ }
      if (supabase) {
        const { data: r } = await supabase.auth.getSession();
        if (r.session && alive) {
          const s: Session = { id: r.session.user.id, email: r.session.user.email ?? "", demo: false };
          setSession(s); await load(s, String(r.session.user.user_metadata?.name ?? "Explorer"));
        }
      }
      if (alive) setReady(true);
    })();
    return () => { alive = false; };
  }, [load]);

  useEffect(() => {
    if (!session || !loaded.current) return;
    const t = setTimeout(async () => {
      if (session.demo) {
        try { localStorage.setItem("nb:data:" + session.id, JSON.stringify(data)); } catch { toast("Browser storage is full. Delete some photos."); }
      } else if (supabase) {
        const { error } = await supabase.from("user_state").upsert({ id: session.id, data, updated_at: new Date().toISOString() });
        if (error) toast("Could not save to Supabase: " + error.message);
      }
    }, 500);
    return () => clearTimeout(t);
  }, [data, session, toast]);

  useEffect(() => {
    const el = document.documentElement;
    el.classList.toggle("reduce-motion", data.prefs.reduceMotion);
    el.classList.toggle("large-text", data.prefs.largeText);
  }, [data.prefs.reduceMotion, data.prefs.largeText]);

  const update = useCallback((fn: (d: UserData) => UserData) => setData(fn), []);
  const award = useCallback((xp: number, text: string, stamp?: string) => {
    setData((d) => {
      const t = dayKey();
      let streak = d.streak;
      if (d.lastActive !== t) streak = d.lastActive === dayKey(new Date(Date.now() - 864e5)) ? d.streak + 1 : 1;
      const stamps = stamp && !d.stamps.includes(stamp) ? [...d.stamps, stamp] : d.stamps;
      return { ...d, xp: d.xp + xp, streak, lastActive: t, stamps, activity: [{ id: Math.random().toString(36).slice(2), text, date: new Date().toISOString(), xp }, ...d.activity].slice(0, 30) };
    });
    toast(`+${xp} XP · ${text}`);
  }, [toast]);

  const startDemo = useCallback(async (name: string, avatar?: File | null) => {
    const s: Session = { id: "demo", email: "demo@local", demo: true };
    localStorage.setItem("nb:session", JSON.stringify(s));
    const existing = localStorage.getItem("nb:data:demo");
    if (existing && !name) { setSession(s); await load(s, "Explorer"); setReady(true); return; }
    let d = seedDemo(newUserData(name || "Explorer"));
    if (avatar) { try { d = { ...d, profile: { ...d.profile, avatar: await blobToUrl(await resize(avatar, 256)) } }; } catch { /* ignore */ } }
    try { localStorage.setItem("nb:data:demo", JSON.stringify(d)); } catch { /* ignore */ }
    loaded.current = false; setData(d); loaded.current = true; setSession(s); setReady(true);
  }, [load]);

  const signUp = useCallback(async (email: string, password: string, name: string, avatar?: File | null) => {
    if (!supabase) return "Supabase is not configured.";
    const { data: r, error } = await supabase.auth.signUp({ email, password, options: { data: { name } } });
    if (error) return error.message;
    pendingAvatar.current = avatar ?? null;
    if (!r.session || !r.user) return "CONFIRM";
    const s: Session = { id: r.user.id, email, demo: false };
    setSession(s); await load(s, name);
    setData((d) => ({ ...d, profile: { ...d.profile, name } }));
    return null;
  }, [load]);

  const signIn = useCallback(async (email: string, password: string) => {
    if (!supabase) return "Supabase is not configured.";
    const { data: r, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) return error.message;
    const s: Session = { id: r.user.id, email, demo: false };
    setSession(s); await load(s, String(r.user.user_metadata?.name ?? "Explorer"));
    return null;
  }, [load]);

  const oauth = useCallback(async (provider: "google" | "github") => {
    if (supabase) await supabase.auth.signInWithOAuth({ provider, options: { redirectTo: window.location.origin + "/dashboard" } });
  }, []);

  const signOut = useCallback(async () => {
    if (sref.current?.demo) localStorage.removeItem("nb:session");
    else if (supabase) await supabase.auth.signOut();
    loaded.current = false; setSession(null); setData(newUserData("Explorer"));
  }, []);

  return (
    <C.Provider value={{ ready, session, data, toastMsg, update, award, startDemo, signUp, signIn, oauth, signOut, upload, toast }}>
      {children}
      <div role="status" aria-live="polite" className="pointer-events-none fixed inset-x-0 bottom-20 z-[60] flex justify-center px-4 lg:bottom-6">
        {toastMsg && <div className="animate-fade-up rounded-full bg-forest-900 px-5 py-3 text-sm font-medium text-cream-50 shadow-xl ring-1 ring-gold-400/40">{toastMsg}</div>}
      </div>
    </C.Provider>
  );
}
