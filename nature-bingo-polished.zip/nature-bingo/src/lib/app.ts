import type { IconName } from "@/components";

export type Difficulty = "Easy" | "Medium" | "Hard";
export type Setting = "Outdoor" | "Indoor";
export type StampKey = "forest" | "bird" | "plant" | "mountain" | "sky" | "water";
export type SceneKind = "forest" | "lake" | "sunrise" | "meadow" | "mountain";

export interface Quest {
  id: string; title: string; description: string; minutes: number;
  difficulty: Difficulty; setting: Setting; stamp: StampKey; done: boolean;
  source: "gemma" | "demo"; model?: string; ms?: number; createdAt: string;
}
export interface JournalEntry { id: string; title: string; notes: string; image?: string; scene: SceneKind; date: string }
export interface Post { id: string; author: string; text: string; date: string; mine?: boolean }
export interface Prefs {
  interests: string[]; minutes: number; difficulty: Difficulty; setting: Setting;
  reduceMotion: boolean; largeText: boolean; reminders: boolean; onboarded: boolean;
}
export interface Profile { name: string; bio: string; avatar?: string }
export interface Activity { id: string; text: string; date: string; xp: number }
export interface UserData {
  profile: Profile; xp: number; streak: number; lastActive: string;
  quests: Quest[]; bingo: { tiles: string[]; done: boolean[]; lineBonus: boolean };
  stamps: string[]; visited: string[]; screen: Record<string, number>; goal: number;
  joined: string[]; posts: Post[]; journal: JournalEntry[]; prefs: Prefs; activity: Activity[];
}

export type Variant = "primary" | "gold" | "ghost" | "danger";
export const btnCls = (v: Variant = "primary", size: "sm" | "md" = "md") =>
  `inline-flex items-center justify-center gap-2 rounded-xl font-semibold tracking-tight transition-all duration-200 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-gold-400/50 disabled:cursor-not-allowed disabled:opacity-50 active:scale-[.97] ${size === "sm" ? "px-3.5 py-1.5 text-sm" : "px-5 py-2.5"} ${
    v === "primary" ? "bg-gradient-to-b from-forest-600 to-forest-700 text-cream-50 shadow-[0_1px_0_rgba(255,255,255,.18)_inset,0_6px_14px_-6px_rgba(20,45,33,.6)] hover:-translate-y-0.5 hover:from-forest-500 hover:to-forest-600"
    : v === "gold" ? "bg-gradient-to-b from-gold-300 to-gold-500 text-forest-950 shadow-[0_1px_0_rgba(255,255,255,.5)_inset,0_6px_14px_-6px_rgba(127,90,18,.7)] hover:-translate-y-0.5 hover:brightness-105"
    : v === "danger" ? "bg-red-700 text-white shadow-md hover:-translate-y-0.5 hover:bg-red-600"
    : "border border-forest-900/15 bg-cream-50 text-forest-800 shadow-sm hover:-translate-y-0.5 hover:border-forest-900/30 hover:bg-white"}`;
export const field = "w-full rounded-xl border border-forest-900/15 bg-white px-3.5 py-2.5 text-forest-900 shadow-sm transition placeholder:text-forest-900/40 hover:border-forest-900/30 focus:border-forest-500 focus:outline-none focus:ring-4 focus:ring-forest-500/20";
export const labelCls = "mb-1 mt-4 block text-sm font-semibold text-forest-800";


export const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36);
export const dayKey = (d = new Date()) => d.toISOString().slice(0, 10);
export const levelOf = (xp: number) => Math.floor(xp / 100) + 1;
const TITLES = ["Seedling", "Sprout", "Explorer", "Ranger", "Guardian", "Elder Oak"];
export const levelName = (xp: number) => TITLES[Math.min(TITLES.length - 1, Math.floor(levelOf(xp) / 2))];
export const XP_BY_DIFFICULTY = { Easy: 20, Medium: 30, Hard: 50 } as const;

export function lastDays(n: number): { key: string; label: string }[] {
  const out: { key: string; label: string }[] = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(Date.now() - i * 864e5);
    out.push({ key: dayKey(d), label: d.toLocaleDateString("en", { weekday: "short" }) });
  }
  return out;
}

export const INTERESTS: { name: string; icon: IconName }[] = [
  { name: "Birds", icon: "bird" }, { name: "Plants", icon: "leaf" }, { name: "Photography", icon: "camera" },
  { name: "Hiking", icon: "mountain" }, { name: "Wildlife", icon: "heart" }, { name: "Gardening", icon: "flower" },
  { name: "Mindfulness", icon: "drop" },
];

export const BINGO_POOL: { t: string; i: IconName }[] = [
  { t: "Find a bird", i: "bird" }, { t: "Touch a tree", i: "leaf" }, { t: "Spot a flower", i: "flower" },
  { t: "See a butterfly", i: "sparkles" }, { t: "Listen to nature", i: "music" }, { t: "Watch the clouds", i: "cloud" },
  { t: "Take a nature photo", i: "camera" }, { t: "Feel the sun", i: "sun" }, { t: "Find a unique leaf", i: "leaf" },
  { t: "Hear running water", i: "drop" }, { t: "Find a smooth stone", i: "mountain" }, { t: "Notice the breeze", i: "cloud" },
  { t: "Watch a sunrise or sunset", i: "sun" }, { t: "Smell a plant", i: "flower" }, { t: "Spot an insect", i: "sparkles" },
  { t: "Find a feather", i: "bird" }, { t: "Spot a squirrel", i: "heart" }, { t: "Find tree bark patterns", i: "leaf" },
];
export const defaultTiles = () => BINGO_POOL.slice(0, 9).map((b) => b.t);
export const shuffledTiles = () => [...BINGO_POOL].sort(() => Math.random() - 0.5).slice(0, 9).map((b) => b.t);
const LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
export const hasLine = (done: boolean[]) => LINES.some((l) => l.every((i) => done[i]));

export const STAMPS: { key: string; label: string; hint: string; icon: IconName }[] = [
  { key: "forest", label: "Forest Walk", hint: "Complete a forest quest", icon: "leaf" },
  { key: "bird", label: "Bird Watcher", hint: "Complete a bird quest", icon: "bird" },
  { key: "plant", label: "Plant Lover", hint: "Complete a plant quest", icon: "flower" },
  { key: "mountain", label: "Mountain View", hint: "Complete a hiking quest", icon: "mountain" },
  { key: "sky", label: "Sky Gazer", hint: "Complete a sky or photo quest", icon: "sun" },
  { key: "water", label: "Water Lover", hint: "Complete a mindfulness quest", icon: "drop" },
  { key: "park", label: "Park Visitor", hint: "Visit a park", icon: "pin" },
  { key: "trail", label: "Trail Walker", hint: "Visit a trail", icon: "mountain" },
  { key: "garden", label: "Garden Guest", hint: "Visit a garden", icon: "flower" },
  { key: "woods", label: "Forest Explorer", hint: "Visit a forest", icon: "leaf" },
  { key: "bingo", label: "Bingo Line", hint: "Complete a bingo line", icon: "grid" },
  { key: "journal", label: "Memory Keeper", hint: "Write a journal entry", icon: "book" },
];
export const STAMP_FOR_TYPE: Record<string, string> = { Parks: "park", Trails: "trail", Gardens: "garden", Forests: "woods" };
export const SCENE_FOR_STAMP: Record<StampKey, SceneKind> = { forest: "forest", bird: "lake", plant: "meadow", mountain: "mountain", sky: "sunrise", water: "lake" };

export const SPOTS: { id: string; name: string; type: "Parks" | "Trails" | "Gardens" | "Forests"; km: number; min: number; desc: string; scene: SceneKind; x: number; y: number }[] = [
  { id: "s1", name: "Riverside Park", type: "Parks", km: 1.2, min: 15, desc: "Wide paths and shaded benches by the river.", scene: "meadow", x: 30, y: 38 },
  { id: "s2", name: "Botanical Garden", type: "Gardens", km: 2.5, min: 30, desc: "Seasonal flower beds and a quiet greenhouse.", scene: "meadow", x: 62, y: 28 },
  { id: "s3", name: "Green Valley Trail", type: "Trails", km: 3.6, min: 45, desc: "Gentle climb with open valley views.", scene: "mountain", x: 74, y: 62 },
  { id: "s4", name: "Lakeside Walk", type: "Trails", km: 4.1, min: 50, desc: "Flat lakeside loop, great at sunset.", scene: "lake", x: 22, y: 70 },
  { id: "s5", name: "Pine Woods", type: "Forests", km: 5.0, min: 60, desc: "Cool pine forest with birdsong all morning.", scene: "forest", x: 48, y: 78 },
  { id: "s6", name: "Heritage Orchard", type: "Gardens", km: 2.1, min: 25, desc: "Old fruit trees and wildflower margins.", scene: "sunrise", x: 50, y: 52 },
];

export const CHALLENGES: { id: string; title: string; desc: string; target: number; unit: string; scene: SceneKind; progress: (d: UserData) => number }[] = [
  { id: "c1", title: "7 Days Outside", desc: "Be active outdoors seven days in a row.", target: 7, unit: "days", scene: "forest", progress: (d) => d.streak },
  { id: "c2", title: "Photo Hunt", desc: "Add five journal entries with a photo.", target: 5, unit: "photos", scene: "meadow", progress: (d) => d.journal.filter((j) => j.image).length },
  { id: "c3", title: "Weekly Bingo", desc: "Fill a full row, column or diagonal.", target: 3, unit: "in a line", scene: "lake", progress: (d) => Math.min(3, d.bingo.done.filter(Boolean).length) },
];

export const BADGES: { id: string; name: string; desc: string; icon: IconName; test: (d: UserData) => boolean }[] = [
  { id: "b1", name: "First Steps", desc: "Complete your first quest", icon: "leaf", test: (d) => d.quests.some((q) => q.done) },
  { id: "b2", name: "Bingo Line", desc: "Complete a line on the board", icon: "grid", test: (d) => hasLine(d.bingo.done) },
  { id: "b3", name: "Full House", desc: "Fill the whole bingo board", icon: "trophy", test: (d) => d.bingo.done.every(Boolean) },
  { id: "b4", name: "3-Day Streak", desc: "Be active 3 days in a row", icon: "flame", test: (d) => d.streak >= 3 },
  { id: "b5", name: "7-Day Streak", desc: "Be active 7 days in a row", icon: "flame", test: (d) => d.streak >= 7 },
  { id: "b6", name: "Journal Keeper", desc: "Write 3 journal entries", icon: "book", test: (d) => d.journal.length >= 3 },
  { id: "b7", name: "Trail Scout", desc: "Visit 3 places", icon: "pin", test: (d) => d.visited.length >= 3 },
  { id: "b8", name: "Nature Explorer", desc: "Earn 250 XP", icon: "compass", test: (d) => d.xp >= 250 },
  { id: "b9", name: "Green Champion", desc: "Earn 750 XP", icon: "award", test: (d) => d.xp >= 750 },
];

export const FEED = [
  { id: "f1", author: "Sarah Green", text: "Spotted a heron on the lakeside walk this morning. Quest and journal done!", daysAgo: 0 },
  { id: "f2", author: "Mike Trail", text: "Finished the 7 Days Outside challenge. Day 7 was a sunrise on the ridge.", daysAgo: 1 },
  { id: "f3", author: "Priya Rivers", text: "Tip: keep the phone in your jacket pocket. You notice so much more.", daysAgo: 2 },
];
export const LEADERBOARD = [{ name: "Alex Carter", xp: 420 }, { name: "Sarah Green", xp: 380 }, { name: "Tom Rivers", xp: 320 }, { name: "Priya Nair", xp: 265 }, { name: "Mike Trail", xp: 190 }];

export function newUserData(name: string): UserData {
  return {
    profile: { name, bio: "" }, xp: 0, streak: 0, lastActive: "", quests: [],
    bingo: { tiles: defaultTiles(), done: Array(9).fill(false), lineBonus: false },
    stamps: [], visited: [], screen: {}, goal: 150, joined: [], posts: [], journal: [],
    prefs: { interests: [], minutes: 15, difficulty: "Easy", setting: "Outdoor", reduceMotion: false, largeText: false, reminders: true, onboarded: false },
    activity: [],
  };
}

/** Realistic sample content used only in local demo mode. */
export function seedDemo(d: UserData): UserData {
  const ago = (n: number) => new Date(Date.now() - n * 864e5).toISOString();
  const days = lastDays(7);
  const mins = [168, 142, 190, 125, 150, 110, 82];
  const screen: Record<string, number> = {};
  days.forEach((x, i) => (screen[x.key] = mins[i]));
  return {
    ...d, xp: 230, streak: 4, lastActive: dayKey(new Date(Date.now() - 864e5)), screen,
    profile: { ...d.profile, bio: d.profile.bio || "Nature lover. Weekend hiker." },
    stamps: ["forest", "bird", "park"], visited: ["s1"], joined: ["c1"],
    bingo: { ...d.bingo, done: [true, false, true, false, true, false, false, true, false] },
    quests: [
      { id: "q1", title: "Forest Trail Discovery", description: "Find a hidden trail nearby and notice five different leaves, textures and colours.", minutes: 15, difficulty: "Easy", setting: "Outdoor", stamp: "forest", done: true, source: "demo", createdAt: ago(3) },
      { id: "q2", title: "Listen and Count", description: "Stand still and note every different bird call you hear.", minutes: 15, difficulty: "Medium", setting: "Outdoor", stamp: "bird", done: true, source: "demo", createdAt: ago(2) },
      { id: "q3", title: "Sunrise Observation", description: "Watch the sky change colour for ten quiet minutes.", minutes: 30, difficulty: "Medium", setting: "Outdoor", stamp: "sky", done: false, source: "demo", createdAt: ago(0) },
    ],
    journal: [
      { id: "j1", title: "Morning Hike", notes: "The light through the trees was perfect. Heard a woodpecker.", scene: "forest", date: ago(1) },
      { id: "j2", title: "Butterfly in the Garden", notes: "Watched a swallowtail for ten minutes. Took no photos on purpose.", scene: "meadow", date: ago(3) },
      { id: "j3", title: "Sunset Views", notes: "Lake was completely still. Best end to the week.", scene: "sunrise", date: ago(5) },
    ],
    activity: [
      { id: "a1", text: "Completed Listen and Count", date: ago(2), xp: 30 },
      { id: "a2", text: "Added journal entry: Morning Hike", date: ago(1), xp: 10 },
      { id: "a3", text: "Visited Riverside Park", date: ago(4), xp: 15 },
    ],
  };
}
